# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys
import traceback
import logging,shutil
import HTMLParser,time
from shutil import copyfile

_plugin_name_='plugin.program.Settingz'
__debuging__="DEBUG_MODE"
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__settings__ = xbmcaddon.Addon(id=_plugin_name_)
addonName = __settings__.getAddonInfo("name")
addonIcon = __settings__.getAddonInfo('icon')
__language__ = __settings__.getLocalizedString
#__cachePeriod__ = __settings__.getSetting("cache")
__PLUGIN_PATH__ = __settings__.getAddonInfo('path')
__DEBUG__ = __settings__.getSetting("DEBUG") == "true"
__addon__ = xbmcaddon.Addon()
ADDON=xbmcaddon.Addon(id=_plugin_name_)
__addonname__ = __addon__.getAddonInfo('name')
__icon__ = __addon__.getAddonInfo('icon')
sys.modules["__main__"].dbg = True
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
#cacheServer = StorageServer.StorageServer("plugin.video.Ebs_RSS", __cachePeriod__)  # (Your plugin name, Cache time in hours)
AddonID = _plugin_name_
Addon = xbmcaddon.Addon(AddonID)
localizedString = Addon.getLocalizedString 
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")

     
LIB_PATH = xbmc.translatePath( os.path.join( __PLUGIN_PATH__, 'resources', 'mail' ) )
sys.path.append (LIB_PATH)
COLOR1         = 'teal'
COLOR2         = 'red'


def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def addDir( name, url, mode, iconimage='DefaultFolder.png'  , fanart='',summary='',isRealFolder=True):
        try:
           
            u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name 
            liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
            liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": urllib.unquote(summary)})
            liz.setProperty('IsPlayable', 'false')
            if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
               
            ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isRealFolder)
            if __DEBUG__:
                 
                print "added directory success:" + clean(contentType, name) + " url=" + clean('utf-8',u)
            return ok
        except Exception as e:
            print "WALLA exception in addDir"
            print e
            raise
     
def addDir2_2(name,url,mode,iconimage,fanart,description):

        uinstall_package=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        

        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        
   
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok

def addDir2(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Audio", infoLabels={ "Title": name } )
    if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok

def main_menu():
     if xbmc.getCondVisibility('system.platform.ios'):
       addDir("[COLOR magenta][I]**IOS System**[/I][/COLOR]",'www.plugin.',299,__PLUGIN_PATH__ + "/resources/ios.png",__PLUGIN_PATH__ + "/resources/iso.png","זיהוי מערכת",False)
     if xbmc.getCondVisibility('system.platform.android'):
       addDir("[COLOR magenta][I]**Android System**[/I][/COLOR]",'www.plugin.',299,__PLUGIN_PATH__ + "/resources/android.png",__PLUGIN_PATH__ + "/resources/android.png","זיהוי מערכת",False)
     if xbmc.getCondVisibility('system.platform.windows'):
       addDir("[COLOR magenta][I]**Windows System**[/I][/COLOR]",'www.plugin.',299,__PLUGIN_PATH__ + "/resources/windows.png",__PLUGIN_PATH__ + "/resources/windows.png","זיהוי מערכת",False)
     addDir3("[COLOR powederblue]טורנטר[/COLOR]",'plugin.',2,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
     addDir3("[COLOR powederblue]Kmedia Torrent[/COLOR]",'plugin.',7,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
     addDir3("[COLOR powederblue]קודי פופקורן[/COLOR]",'plugin.',3,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
     addDir3("[COLOR powederblue]קוואסר[/COLOR]",'plugin.',9,__PLUGIN_PATH__ + "/resources/quasar.png",__PLUGIN_PATH__ + "/resources/quasar.png","התקן את קוואסר")
     addDir3("[COLOR powederblue]אלמנטום[/COLOR]",'plugin.',13,__PLUGIN_PATH__ + "/resources/elementum.png",__PLUGIN_PATH__ + "/resources/elementum.png","התקן את אלמנטום")
     addDir3("[COLOR khaki]Gdrive[/COLOR]",'plugin.',4,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן אל גוגל דרייב")
     if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq_Subs') or os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
       addDir2("[COLOR purple]התקנת נגנים לצ'אפי[/COLOR]",'plugin.',8,__PLUGIN_PATH__ + "/resources/metaliq.png",__PLUGIN_PATH__ + "/resources/metaliq.png","מתקינה את כל נגני מטליק")
     addDir2("[COLOR lime]הגדר באפר עד זכרון 1.5 ראם[/COLOR]",'plugin.',11,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר עד זכרון 1.5 ראם")
     addDir2("[COLOR lime]הגדר באפר עד 2 ראם[/COLOR]",'plugin.',20,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר עד 2 ראם")
     addDir2("[COLOR lime]הגדר באפר מ 3 ראם ומעלה[/COLOR]",'plugin.',21,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר מ 3 ראם ומעלה") 
     addDir2("[COLOR lime]הגדר באפר למכשירי Mibox[/COLOR]",'plugin.',25,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר באפר למכשירי Mibox")
     addDir2("[COLOR lime]הסר סיסמת מבוגרים[/COLOR]",'plugin.',14,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הסר סיסמת מבוגרים")
     addDir2("[COLOR lime]התאם את הגופן לשפות אחרות[/COLOR]",'plugin.',15,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","התאם את הגופן לשפות אחרות")
     addDir2("[COLOR lime]תיקון שגיאה בויזארד[/COLOR]",'plugin.',16,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","תיקון שגיאה בויזארד")
     addDir2("[COLOR lime]ניקוי נוגן לאחרונה[/COLOR]",'plugin.',17,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","ניקוי נוגן לאחרונה")
     addDir2("[COLOR lime]הגדר דיאלוג פשוט בנגנים[/COLOR]",'plugin.',18,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר דיאלוג פשוט בנגנים")
     addDir2("[COLOR lime]הגדר דיאלוג מתקדם בנגנים[/COLOR]",'plugin.',19,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","הגדר דיאלוג מתקדם בנגנים")
     addDir2("[COLOR lime]עדכן מאגר סרטים[/COLOR]",'plugin.',22,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","עדכן מאגר סרטים בנגנים")
     addDir2("[COLOR lime]תיקון הגדרות סקין פרימיום[/COLOR]",'plugin.',23,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","תיקון הגדרות סקין פרימיום")
     addDir2("[COLOR lime]תיקון הגדרות סקין אמיננס[/COLOR]",'plugin.',24,__PLUGIN_PATH__ + "/resources/buffer.jpg",__PLUGIN_PATH__ + "/resources/buffer.jpg","תיקון הגדרות סקין אמיננס")
     addDir2("[COLOR lightblue]ניקוי תקיות מיותרות[/COLOR]",'plugin.',10,__PLUGIN_PATH__ + "/resources/clean.jpg",__PLUGIN_PATH__ + "/resources/clean.jpg","ניקוי תקיות לא קשורות למערכת שלנו")
     #addDir3("[COLOR powederblue]התקן או הפעל[/COLOR]",'torrenter',12,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
     #ActivateWindow(10001,&quot;plugin://plugin.program.Settingz/?mode=12&amp;url=torrenter&quot;,return)
def dis_or_enable_addon(addon_id,mode, enable="true"):
    import json
    addon = '"%s"' % addon_id
    if xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "true":
        logging.warning('already Enabled')
        return xbmc.log("### Skipped %s, reason = allready enabled" % addon_id)
    elif not xbmc.getCondVisibility("System.HasAddon(%s)" % addon_id) and enable == "false":
        return xbmc.log("### Skipped %s, reason = not installed" % addon_id)
    else:
        do_json = '{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{"addonid":%s,"enabled":%s}}' % (addon, enable)
        query = xbmc.executeJSONRPC(do_json)
        response = json.loads(query)
        if enable == "true":
            xbmc.log("### Enabled %s, response = %s" % (addon_id, response))
        else:
            xbmc.log("### Disabled %s, response = %s" % (addon_id, response))
    if mode=='auto':
     return True
    return xbmc.executebuiltin('Container.Update(%s)' % xbmc.getInfoLabel('Container.FolderPath'))
def _iter_python26(node):
  return [node] + node.findall('.//*')
def install_package(url,with_massage,mode='manual'):
   extension=url.split("$$$")
   logging.warning(url)
   if 'http' in url:
    if not os.path.exists(xbmc.translatePath("special://home/addons/") + extension[2].rstrip('\r\n').replace('%24','$')) or mode=='auto':


      logging.warning(extension)
      #downloader_is(extension[0],extension[1],with_massage)
      download(extension[0],extension[1])

      logging.warning(extension[2])
      dis_or_enable_addon(extension[2].rstrip('\r\n'),mode)
     
    elif with_massage=='yes':
      dialog = xbmcgui.Dialog()
      choice=dialog.yesno("Kodi Maintenance", '','[B][COLOR red]Already Installed[/COLOR][/B]', "Install again Any way?")
      if    choice :
        #downloader_is(extension[0],extension[1],'false')
        download(extension[0],extension[1])
        dis_or_enable_addon(extension[2].rstrip('\r\n'),mode)
        
   else:
     from xml.etree import ElementTree as et
    
     src=extension[0]
     dst=extension[1]+'/settings.xml'
     logging.warning(src)
     logging.warning(dst)
     if 'torrenter' in url:
       src2=__PLUGIN_PATH__ + "/resources/magnetic/setting.xml"
       dst2=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.module.magnetic' ) )+'/settings.xml'

       copyfile(src2,dst2)
       
       src3=__PLUGIN_PATH__ + "/resources/torrenter/setting_libtorrent.xml"
       dst3=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.module.libtorrent' ) )+'/settings.xml'

       copyfile(src3,dst3)
       string_to_change='storage'
     if 'kmedia' in url:
        string_to_change='dlpath'
     elif 'popcorn' in url:
       string_to_change='movies_download_path'
     
       # Read in the file
       file_o=xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime/resources/lib/kodipopcorntime/gui/player.py'

       with open(file_o, 'r') as file :
          filedata = file.read()

        # Replace the target string
       filedata = filedata.replace(": int(xbmc.getInfoLabel('ListItem.VideoResolution')),", ": 1920,#int(xbmc.getInfoLabel('ListItem.VideoResolution')),")

        # Write the file out again
       with open(file_o, 'w') as file:
          file.write(filedata)
     elif 'gdrive' in url:
       string_to_change='NONE'
     elif 'elementum' in url:
       string_to_change='download_path'
       string_to_change2='library_path'
       src2=__PLUGIN_PATH__ + "/resources/elementum/windows_setting.xml"
       dst2=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.elementum' ) )+'/settings.xml'

       src2=__PLUGIN_PATH__ + "/resources/elementum/settings_burst.xml"
       dst2=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.elementum.burst' ) )+'/settings.xml'
       copyfile(src2,dst2)
     elif 'quasar' in url:
       string_to_change='download_path'
       string_to_change2='library_path'
       src2=__PLUGIN_PATH__ + "/resources/quasar/windows_setting.xml"
       dst2=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.quasar' ) )+'/settings.xml'

       src2=__PLUGIN_PATH__ + "/resources/quasar/settings_burst.xml"
       dst2=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.quasar.burst' ) )+'/settings.xml'
       copyfile(src2,dst2)
     if string_to_change!='NONE':
         #dialog = xbmcgui.Dialog()
         #stoarge=dialog.browse( 3, "Temp File Location", "files" )
         stoarge=xbmc.translatePath("special://temp")
      
         if len(stoarge)>2:
             tree = et.parse(src)
             root = tree.getroot()
             
             for rank in root.getiterator('setting'):
                if (rank.get('id',string_to_change))==string_to_change:
                   rank.set('value',stoarge)
                if 'quasar' in url:
                  if (rank.get('id',string_to_change2))==string_to_change2:
                   rank.set('value',stoarge)
                   
                   
       


     if string_to_change!='NONE':
         #dialog = xbmcgui.Dialog()
         #stoarge=dialog.browse( 3, "Temp File Location", "files" )
         stoarge=xbmc.translatePath("special://temp")
      
         if len(stoarge)>2:
             tree = et.parse(src)
             root = tree.getroot()
             
             for rank in root.getiterator('setting'):
                if (rank.get('id',string_to_change))==string_to_change:
                   rank.set('value',stoarge)
                if 'elementum' in url:
                  if (rank.get('id',string_to_change2))==string_to_change2:
                   rank.set('value',stoarge)



             tree.write(src)


   
     copyfile(src,dst)
     if with_massage=='yes':
       dialog = xbmcgui.Dialog()
       dialog.ok("Kodi Setting", 'שינוי הגדרות הצליח')
     if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq_Subs'):
       xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq_Subs/settings/players/all)")
     if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
       xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq/settings/players/all)")
def metaliq_fix():
  link='https://github.com/kodianonymous1/chappai/raw/master/players.zip'
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)

  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.metalliq_Subs/players' ) )
  II111iiii2 = xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.metalliq/players' ) )
     
  f.close()
  extract  ( OOooO , II111iiii,dp )
  extract  ( OOooO , II111iiii2,dp )

  try:
    os.remove(OOooO)
  except:
    pass
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq_Subs'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq_Subs/settings/players/all)")
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq/settings/players/all)")
  dp.close()
def movie_update():
  link='https://github.com/kodianonymous1/Anonymous/raw/master/cache.zip'
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)

  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.OpenD' ) )

     
  f.close()
  extract  ( OOooO , II111iiii,dp )


  try:
    os.remove(OOooO)
  except:
    pass

  dp.close()
def downloader_is (url,name,with_massage ) :
 import downloader,extract   
 i1iIIII = xbmc . getInfoLabel ( "System.ProfileName" )
 I1 = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
 O0OoOoo00o = xbmcgui . Dialog ( )
 if name.find('repo')< 0 and with_massage=='yes':
     choice = O0OoOoo00o . yesno ( "XBMC ISRAEL" , "Yes to install" ,name)
 else:
     choice=True
 if    choice :
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  try :
     os . remove ( OOooO )
  except :
      pass
  downloader . download ( url , OOooO ,name, iiiI11 )
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
  iiiI11 . update ( 0 , name , "Extracting Zip Please Wait" )
  
  extract . all ( OOooO , II111iiii , iiiI11 )
  iiiI11 . update ( 0 , name , "Downloading" )
  iiiI11 . update ( 0 , name , "Extracting Zip Please Wait" )
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )

def torent_menu():
  type='windows'
  if xbmc.getCondVisibility('system.platform.android'):
       type='android'
  #dialog = xbmcgui.Dialog()
  #system=['Windows','Android']
  #ret = dialog.select("בחר מערכת להתקנה", system)
  #if ret==0:
  # type='windows'
  #elif ret==1:
  # type='android'
  #else:
  # sys.exit()
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$torrenter$$$'+type,5,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$torrenter$$$'+type,5,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
def normalize(s):
    if type(s) == unicode: 
        return s.encode('utf8', 'ignore')
    else:
        return str(s)
def extract(src,dst,dp):
    import zipfile
    logging.warning(src)
    zin = zipfile.ZipFile(src,  'r')

    nFiles = float(len(zin.infolist()))
    count  = 0
    reload(sys)
    sys.setdefaultencoding("utf-8")
    
    for item in zin.infolist():
            count += 1
            update = count / nFiles * 100
            dp.update(int(update),'Extracting')
            logging.warning(item.filename)
            logging.warning(dst)
            item.filename=normalize(item.filename)
            zin.extract(item, dst)
    

    return True
def download(link,dest):
  iiI1iIiI = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
  iiiI11 = xbmcgui . DialogProgress ( )
  iiiI11 . create ( "XBMC ISRAEL" , "Downloading " +name, '' , 'Please Wait' )
  OOooO = os . path . join ( iiI1iIiI , 'isr.zip' )
  req = urllib2.Request(link)
  remote_file = urllib2.urlopen(req)
  #the_page = response.read()
  dp = xbmcgui.DialogProgress()
  dp.create("Downloading", "Downloading " +name)
  dp.update(0)
  images_file=dest
  f = open(OOooO, 'wb')

  try:
    total_size = remote_file.info().getheader('Content-Length').strip()
    header = True
  except AttributeError:
        header = False # a response doesn't always include the "Content-Length" header

  if header:
        total_size = int(total_size)

  bytes_so_far = 0
  start_time=time.time()
  while True:
        buffer = remote_file.read(8192)
        if not buffer:
            sys.stdout.write('\n')
            break

        bytes_so_far += len(buffer)
        f.write(buffer)

        if not header:
            total_size = bytes_so_far # unknown size
        if dp.iscanceled(): 
           dp.close()
           try:
            os.remove(OOooO)
           except:
            pass
           break
        percent = float(bytes_so_far) / total_size
        percent = round(percent*100, 2)
        currently_downloaded=bytes_so_far/ (1024 * 1024) 
        total=total_size/ (1024 * 1024) 
        mbs = '[COLOR %s][B]Size:[/B] [COLOR %s]%.02f[/COLOR] MB of [COLOR %s]%.02f[/COLOR] MB[/COLOR]' % ('teal', 'skyblue', currently_downloaded, 'teal', total) 
        if (time.time() - start_time) >0:
          kbps_speed = bytes_so_far / (time.time() - start_time) 
          kbps_speed = kbps_speed / 1024 
        else:
         kbps_speed=0
        type_speed = 'KB'
        if kbps_speed >= 1024:
           kbps_speed = kbps_speed / 1024 
           type_speed = 'MB'
        if kbps_speed > 0 and not percent == 100: 
            eta = (total_size - bytes_so_far) / kbps_speed 
        else: 
            eta = 0
        e   = '[COLOR %s][B]Speed:[/B] [COLOR %s]%.02f [/COLOR]%s/s ' % ('teal', 'skyblue', kbps_speed, type_speed)

        dp.update(int(percent), "Downloading " +name,mbs,e )
        #sys.stdout.write("Downloaded %d of %d bytes (%0.2f%%)\r" % (bytes_so_far, total_size, percent))
  
  II111iiii = xbmc . translatePath ( os . path . join ( 'special://home' , 'addons' ) )
     
  f.close()

  extract  ( OOooO , II111iiii,dp )
  if os.path.exists(II111iiii+'/scakemyer-script.quasar.burst'):
    if os.path.exists(II111iiii+'/script.quasar.burst'):
     shutil.rmtree(II111iiii+'/script.quasar.burst' , ignore_errors=False)
    os.rename(II111iiii+'/scakemyer-script.quasar.burst',II111iiii+'/script.quasar.burst')
  if os.path.exists(II111iiii+'/scakemyer-script.elementum.burst'):
    if os.path.exists(II111iiii+'/script.elementum.burst'):
     shutil.rmtree(II111iiii+'/script.elementum.burst' , ignore_errors=False)
    os.rename(II111iiii+'/scakemyer-script.elementum.burst',II111iiii+'/script.elementum.burst')
  if os.path.exists(II111iiii+'/plugin.video.kmediatorrent-master'):
    if os.path.exists(II111iiii+'/plugin.video.kmediatorrent'):
     shutil.rmtree(II111iiii+'/plugin.video.kmediatorrent' , ignore_errors=False)
    os.rename(II111iiii+'/plugin.video.kmediatorrent-master',II111iiii+'/plugin.video.kmediatorrent')
  xbmc . executebuiltin ( 'UpdateLocalAddons ' )
  xbmc . executebuiltin ( "UpdateAddonRepos" )
  try:
    os.remove(OOooO)
  except:
    pass
  dp.close()
def popcorn_menu():
  type='windows'
  if xbmc.getCondVisibility('system.platform.android'):
       type='android'
  '''
  dialog = xbmcgui.Dialog()
  system=['Windows','Android']
  ret = dialog.select("בחר מערכת להתקנה", system)
  if ret==0:
   type='windows'
  elif ret==1:
   type='android'
  else:
   sys.exit()
  '''
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$popcorn$$$'+type,5,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$popcorn$$$'+type,5,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")

def gdrive_menu():
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$gdrive$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן אל גוגל דרייב")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$gdrive$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן אל גוגל דרייב")
def kmedia_menu():
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$kmedia$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$kmedia$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
def quasar_menu():
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$quasar$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/quasar.png",__PLUGIN_PATH__ + "/resources/quasar.png","התקן את קוואסר")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$quasar$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/quasar.png",__PLUGIN_PATH__ + "/resources/quasar.png","התקן את קוואסר")
def elementum_menu():
  addDir2("[COLOR blue]התקנה אוטומטית[/COLOR]",'auto$$$elementum$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/elementum.png",__PLUGIN_PATH__ + "/resources/elementum.png","התקן את אלמנטום")
  addDir3("[COLOR blue]התקנה ידנית[/COLOR]",'manual$$$elementum$$$'+'windows',5,__PLUGIN_PATH__ + "/resources/elementum.png",__PLUGIN_PATH__ + "/resources/elementum.png","התקן את אלמנטום")

def clean_folders():
  import shutil
  if xbmc.getCondVisibility('system.platform.ios'):
       system_type='ios'
  if xbmc.getCondVisibility('system.platform.android'):
       system_type='android'
  if xbmc.getCondVisibility('system.platform.windows'):
       system_type='windows'
  ##quasar clean
  quasar_folder=(xbmc.translatePath("special://home/addons/") + 'plugin.video.quasar'+'/resources/bin/')
  ##elementum clean
  elementum_folder=(xbmc.translatePath("special://home/addons/") + 'plugin.video.elementum'+'/resources/bin/')

  popcorn_folder=(xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime'+'/resources/bin/')
  kmdia_folder=(xbmc.translatePath("special://home/addons/") + 'plugin.video.kmediatorrent'+'/resources/bin/')
  dp = xbmcgui.DialogProgress()
  dp.create("מנקה", "אנא המתן... ")
  dp.update(0)
  if os.path.exists(elementum_folder):
      folders=os.listdir(elementum_folder)

      
      for folder in folders:
        dp.update(0, "מנקה אלמנטום")

        if system_type not in folder:
         shutil.rmtree( elementum_folder+folder , ignore_errors=False)
  if os.path.exists(quasar_folder):
      folders=os.listdir(quasar_folder)

      
      for folder in folders:
        dp.update(0, "מנקה קוואסר")

        if system_type not in folder:
         shutil.rmtree( quasar_folder+folder , ignore_errors=False)
  if os.path.exists(popcorn_folder):
      folders=os.listdir(popcorn_folder)

      for folder in folders:
        dp.update(0, "מנקה פופקורן")
        if system_type not in folder:
         shutil.rmtree( popcorn_folder+folder , ignore_errors=False)
         
  if os.path.exists(kmdia_folder):
      folders=os.listdir(kmdia_folder)

      for folder in folders:
        dp.update(0, "מנקה קמדיה")
        if system_type not in folder:
         shutil.rmtree( kmdia_folder+folder , ignore_errors=False)
  dp.update(0, "סיום")
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'הכל נקי :-)')
def fix_buffer():
  src=__PLUGIN_PATH__ + "/resources/buffer/1/advancedsettings.xml"
  dst=xbmc . translatePath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'הבאפר הוגדר בהצלחה - הקודי יסגר כעט')
  os._exit(1)
def fix_buffer2():
  src=__PLUGIN_PATH__ + "/resources/buffer/2/advancedsettings.xml"
  dst=xbmc . translatePath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'הבאפר הוגדר בהצלחה - הקודי יסגר כעט)')
  os._exit(1)
def fix_buffer3():
  src=__PLUGIN_PATH__ + "/resources/buffer/3/advancedsettings.xml"
  dst=xbmc . translatePath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'הבאפר הוגדר בהצלחה - הקודי יסגר כעט')
  os._exit(1)
def fix_buffer4():
  src=__PLUGIN_PATH__ + "/resources/buffer/4/advancedsettings.xml"
  dst=xbmc . translatePath ( 'special://userdata')+"/advancedsettings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'הבאפר הוגדר בהצלחה - הקודי יסגר כעט')
  os._exit(1)
def skin_pfix():
  src=__PLUGIN_PATH__ + "/resources/skinpfix/settings.xml"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/skin.Premium.mod')+"/settings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'תיקון עבר בהצלחה הקודי יעשה יסגר כעט :-)')
  os._exit(1)
def skin_efix():
  src=__PLUGIN_PATH__ + "/resources/skinefix/settings.xml"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/skin.anonymous.mod')+"/settings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'תיקון עבר בהצלחה הקודי יעשה יסגר כעט :-)')
  os._exit(1)

def clean_pass():
  src=__PLUGIN_PATH__ + "/resources/pinsentry_database.db"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/script.pinsentry')+"/pinsentry_database.db"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'סיסמה הוסרה :-)')
def fix_font():
  src=__PLUGIN_PATH__ + "/resources/Font.xml"
  dst=xbmc . translatePath ( 'special://home/addons/skin.anonymous.mod/16x9')+"/Font.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'שינוי פונט הותקן בהצלחה, הפעל מחדש את הקודי :-)')
def last_play():
  src=__PLUGIN_PATH__ + "/resources/lastPlayed.json"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.last_played')+"/lastPlayed.json"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'ניקוי נוגן לאחרונה הושלם בהצלחה :-)')
def normal_metalliq():
  src=__PLUGIN_PATH__ + "/resources/metalliq/1/settings.xml"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.metalliq')+"/settings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'דיאלוג פשוט הוגדר בהצלחה :-)')
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq/settings/players/all)")

def fast_metalliq():
  src=__PLUGIN_PATH__ + "/resources/metalliq/2/settings.xml"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.video.metalliq')+"/settings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'דיאלוג מתקדם הוגדר בהצלחה :-)')
  if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.metalliq'):
    xbmc.executebuiltin("RunPlugin(plugin://plugin.video.metalliq/settings/players/all)")
def fix_wizard():
  src=__PLUGIN_PATH__ + "/resources/settings.xml"
  dst=xbmc . translatePath ( 'special://userdata/addon_data/plugin.program.Anonymous')+"/settings.xml"
  
  copyfile(src,dst)
  dialog = xbmcgui.Dialog()
  dialog.ok("Kodi Setting", 'תיקון הויזארד עבר בהצלחה :-)')
def run_or_install(url):
   type='windows'
   if xbmc.getCondVisibility('system.platform.android'):
       type='android'
   item=url
   
   addon_folder=''
   if item=='torrenter':
     addon_folder='plugin.video.torrenter/'
     names='torrenter'
   else:
     logging.warning(item)
   if item=='popcorn':
     addon_folder='plugin.video.kodipopcorntime/'
     names='popcorn'
   if item=='quasar':
     addon_folder='plugin.video.quasar/'
     names='quasar'
   if item=='elementum':
     addon_folder='plugin.video.elementum/'
     names='elementum'
   if item=='kmedia':
     addon_folder='plugin.video.kmediatorrent/'
     names='kmedia'
   if item=='gdrive':
     addon_folder='plugin.video.gdrive/'
     names='gdrive'
   logging.warning(addon_folder)
   if os.path.exists(xbmc.translatePath("special://home/addons/") + addon_folder):
       string='ActivateWindow(10025,"plugin://'+addon_folder+'",return)'
       xbmc.executebuiltin(string)
       logging.warning(string)
   else:
     install_pack('auto$$$'+names+'$$$'+type)
   sys.exit()
def install_pack(url):
  logging.warning(url)
  target=url.split('$$$')[1]
  modes=url.split('$$$')[0]
  type=url.split('$$$')[2]
 
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.torrenter' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kodipopcorntime' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.gdrive' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.module.magnetic' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kmediatorrent' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.quasar' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.quasar.burst' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.elementum' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.elementum.burst' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  user_dataDir=xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/script.module.libtorrent' ) )
  if not os.path.exists(user_dataDir): # check if folder doesnt exist 
     os.makedirs(user_dataDir) # create if it doesnt
  logging.warning(modes)
  torrent_list=('https://bitbucket.org/DiMartino/myshows.me-kodi-repo/downloads/repository.myshows.me.zip$$$Myshows Me$$$repository.myshows.me',

                #'https://github.com/Pivosgroup/script.module.chardet/archive/master.zip$$$Chardet$$$script.module.chardet',
                'https://github.com/inpos/script.module.pyrrent2http/archive/master.zip$$$pyrrent2http$$$script.module.pyrrent2http',
                'http://vadyur.github.io/kodi_repo/repo/script.module.torrent2http/script.module.torrent2http-0.2.9.zip$$$torrent2http$$$script.module.torrent2http',
                'https://archive.org/download/script.module.libtorrent/script.module.libtorrent.zip$$$libtorrent$$$script.module.libtorrent',
                'https://github.com/nkvoronov/script.module.torrent.ts/archive/master.zip$$$.torrent.ts$$$script.module.torrent.ts',
                'https://archive.org/download/plugin.video.torrenter-5.1.3/plugin.video.torrenter-5.1.3.zip$$$torrenter$$$plugin.video.torrenter',
                #'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.EZTV/torrenter.searcher.EZTV-1.0.3.zip$$$searcher.EZTV$$$torrenter.searcher.EZTV',
                'https://svn.riouxsvn.com/magnetic/script.magnetic.thepiratebay-mc/script.magnetic.thepiratebay-mc-1.0.1.zip$$$searcher.ThePirateBay$$$script.magnetic.thepiratebay-mc',
                #'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.uTorrentCoIL/torrenter.searcher.uTorrentCoIL-1.0.0.zip$$$searcher.uTorrentCoIL$$$torrenter.searcher.uTorrentCoIL',
                'https://bitbucket.org/DiMartino/myshows.me-kodi-repo/raw/1ffef6199bae31cb3d026a6ff2268a5f0b12ca08/repo/torrenter.searcher.KickAssSo/torrenter.searcher.KickAssSo-1.0.4.zip$$$searcher.KickAssSo$$$torrenter.searcher.KickAssSo',
                'https://svn.riouxsvn.com/magnetic/torrenter.searcher.Magnetic/torrenter.searcher.Magnetic-1.0.1.zip$$$searcher.Magnetic$$$torrenter.searcher.Magnetic',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.1337x-mc/script.magnetic.1337x-mc-1.0.0.zip$$$magnetic.1337x$$$script.magnetic.1337x-mc',
                #'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.yts-mc/script.magnetic.yts-mc-1.0.0.zip$$$magnetic.yts$$$script.magnetic.yts-mc',
                #'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.magnetdl-mc/script.magnetic.magnetdl-mc-1.0.0.zip$$$magnetic.magnetdl$$$script.magnetic.magnetdl-mc',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.rarbg-mc/script.magnetic.rarbg-mc-1.0.1.zip$$$magnetic.rarbg$$$script.magnetic.rarbg-mc',
                'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/script.magnetic.idope-mc/script.magnetic.idope-mc-1.0.0.zip$$$magnetic.idope$$$script.magnetic.idope-mc',
                'https://svn.riouxsvn.com/magnetic/script.module.magnetic/script.module.magnetic-1.1.40.zip$$$Magnetic$$$script.module.magnetic'
                #'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/context.magnetic.dialog/context.magnetic.dialog-1.0.6.zip$$$Magnetic.dialog$$$context.magnetic.dialog'
                
                
                
                
                
                )
  quasar_list=(#'https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/repository.quasar/repository.quasar-0.9.78.zip$$$Quasar repository$$$repository.quasar',
               'https://kodihub.net/2offw$$$Quasar$$$plugin.video.quasar',
               'https://archive.org/download/script.quasar.burst/script.quasar.burst.zip$$$Quasar Burst$$$script.quasar.burst'
                )                
  elementum_list=('https://ftp.acc.umu.se/mirror/addons.superrepo.org/v7/addons/repository.quasar/repository.quasar-0.9.78.zip$$$Quasar repository$$$repository.quasar',
               'https://kodihub.net/49pzu$$$Elementum$$$plugin.video.elementum',
               'https://github.com/elgatito/script.elementum.burst/archive/master.zip$$$Elementum Burst$$$script.elementum.burst'
                )                
  if modes=='manual':
    if target=='torrenter':
       for item in torrent_list:
         link=item.split('$$$')[0]
         name1=item.split('$$$')[1]
         name_ext=item.split('$$$')[2]
         name_ext_master=name_ext+'-master'
         
         if os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext) or os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext_master):
           name='[COLOR skyblue]'+name1+'[/COLOR]'
         else:
           name =name1
         addDir2(name,link+'$$$'+name+'$$$'+name_ext,6,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
  
    
      
      
     
      ###########settings#####################
       addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/torrenter/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.torrenter' ) ),6,__PLUGIN_PATH__ + "/resources/torrenter.png",__PLUGIN_PATH__ + "/resources/torrenter.png","התקן את טורנטר")
       
    elif target=='kmedia':
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.kmediatorrent'):
           name='[COLOR skyblue]Kmediatorrent[/COLOR]'
      else:
          name='Kmediatorrent'
      addDir2(name,'https://github.com/kodil/kodil/raw/master/repo/plugin.video.kmediatorrent/plugin.video.kmediatorrent-10.1.3.zip$$$'+name+'$$$plugin.video.kmediatorrent',6,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
      

      addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/kmedia/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kmediatorrent' ) ),6,__PLUGIN_PATH__ + "/resources/kmedia.png",__PLUGIN_PATH__ + "/resources/kmedia.png","התקן את KMEDIA")
      
    elif target=='popcorn':
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime.repository'):
           name='[COLOR skyblue]kodipopcorntime.repository[/COLOR]'
      else:
          name='kodipopcorntime.repository'
      addDir2(name,'https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime.repository/plugin.video.kodipopcorntime.repository-1.1.0.zip$$$'+name+'$$$plugin.video.kodipopcorntime.repository',6,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
      
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.kodipopcorntime'):
           name='[COLOR skyblue]Kodi Popcorntime[/COLOR]'
      else:
          name ='Kodi Popcorntime'
      addDir2(name,'https://kodihub.net/ofbk6$$$'+name+'$$$plugin.video.kodipopcorntime',6,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")

   
      addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/popcorn/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kodipopcorntime' ) ),6,__PLUGIN_PATH__ + "/resources/popcorn.jpg",__PLUGIN_PATH__ + "/resources/popcorn.jpg","התקן את קודי פופקורן")
      
    elif target=='gdrive':
      if os.path.exists(xbmc.translatePath("special://home/addons/") + 'plugin.video.gdrive'):
           name='[COLOR skyblue]Gdrive[/COLOR]'
      else:
          name='Gdrive'
      addDir2(name,'https://github.com/ddurdle/ddurdle.github.io/raw/master/repository.ddurdle/plugin.video.gdrive/plugin.video.gdrive-0.8.52.zip$$$'+name+'$$$plugin.video.gdrive',6,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpgg","התקן את גוגל דרייב")
      

      addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/gdrive/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.gdrive' ) ),6,__PLUGIN_PATH__ + "/resources/gdrive.jpg",__PLUGIN_PATH__ + "/resources/gdrive.jpg","התקן את גוגל דרייב")
    elif target=='elementum':
       for item in elementum_list:
         link=item.split('$$$')[0]
         name1=item.split('$$$')[1]
         name_ext=item.split('$$$')[2]
         name_ext_master=name_ext+'-master'
         
         if os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext) or os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext_master):
           name='[COLOR skyblue]'+name1+'[/COLOR]'
         else:
           name =name1
         logging.warning(xbmc.translatePath("special://home/addons/") + name_ext)
         addDir2(name,link+'$$$'+name+'$$$'+name_ext,6,__PLUGIN_PATH__ + "/resources/elementum.png",__PLUGIN_PATH__ + "/resources/elementum.png","התקן את אלמנטום")

      ###########settings#####################
       addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/elementum/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.elementum' ) ),6,__PLUGIN_PATH__ + "/resources/elementum.png",__PLUGIN_PATH__ + "/resources/elementum.png","התקן את אלמנטום")
    elif target=='quasar':
       for item in quasar_list:
         link=item.split('$$$')[0]
         name1=item.split('$$$')[1]
         name_ext=item.split('$$$')[2]
         name_ext_master=name_ext+'-master'
         
         if os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext) or os.path.exists(xbmc.translatePath("special://home/addons/") + name_ext_master):
           name='[COLOR skyblue]'+name1+'[/COLOR]'
         else:
           name =name1
         logging.warning(xbmc.translatePath("special://home/addons/") + name_ext)
         addDir2(name,link+'$$$'+name+'$$$'+name_ext,6,__PLUGIN_PATH__ + "/resources/quasar.png",__PLUGIN_PATH__ + "/resources/quasar.png","התקן את קוואסר")
  
    
      
      
     
      ###########settings#####################
       addDir2("תיקון הגדרות ההרחבה",__PLUGIN_PATH__ + "/resources/quasar/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.quasar' ) ),6,__PLUGIN_PATH__ + "/resources/quasar.png",__PLUGIN_PATH__ + "/resources/quasar.png","התקן את קווסאר")
       
  elif modes=='auto':
       
       if target=='torrenter':
         for item in torrent_list:
           install_package(item,'NO','auto')

         install_package(__PLUGIN_PATH__ + "/resources/torrenter/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.torrenter' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
       elif target=='kmedia':
         
         install_package('https://github.com/jmarth/plugin.video.kmediatorrent/archive/master.zip$$$'+'kmediatorrent'+'$$$plugin.video.kmediatorrent','NO','auto')
         install_package(__PLUGIN_PATH__ + "/resources/kmedia/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kmediatorrent' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
       elif target=='popcorn':
         install_package('https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime.repository/plugin.video.kodipopcorntime.repository-1.1.0.zip$$$'+'kodipopcorntime.repository'+'$$$plugin.video.kodipopcorntime.repository','NO','auto')
         install_package('https://github.com/markop159/Markop159-repository/raw/master/Releases/plugin.video.kodipopcorntime/plugin.video.kodipopcorntime-1.7.2.zip$$$'+'Kodi Popcorntime'+'$$$plugin.video.kodipopcorntime','NO','auto')
         install_package(__PLUGIN_PATH__ + "/resources/popcorn/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.kodipopcorntime' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
         
       elif target=='gdrive':
         
         install_package('https://github.com/ddurdle/ddurdle.github.io/raw/master/repository.ddurdle/plugin.video.gdrive/plugin.video.gdrive-0.8.52.zip$$$'+'Gdrive'+'$$$plugin.video.gdrive','NO','auto')
         install_package(__PLUGIN_PATH__ + "/resources/gdrive/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.gdrive' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו')
       elif target=='elementum':
         for item in elementum_list:
           install_package(item,'NO','auto')

         install_package(__PLUGIN_PATH__ + "/resources/elementum/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.elementum' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו,יש להפעיל מחדש את הקודי')
         os._exit(1)
       elif target=='quasar':
         for item in quasar_list:
           install_package(item,'NO','auto')

         install_package(__PLUGIN_PATH__ + "/resources/quasar/"+type+'_setting.xml$$$'+xbmc . translatePath ( os . path . join ( 'special://userdata' , 'addon_data/plugin.video.quasar' ) ),'NO','auto')
         dialog = xbmcgui.Dialog()
         dialog.ok("Kodi Setting", 'סיימנו,יש להפעיל מחדש את הקודי')
         os._exit(1)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
        torent_menu()
elif mode==3:
        popcorn_menu()
elif mode==4:
        gdrive_menu()
elif mode==5:
        install_pack(url)
elif mode==6:
      install_package(url,'yes')
elif mode==7:
        kmedia_menu()
elif mode==8:
        metaliq_fix()
elif mode==9:
        quasar_menu()
elif mode==10:
        clean_folders()
elif mode==11:
        fix_buffer()
elif mode==12:
      run_or_install(url)
elif mode==13:
        elementum_menu()
elif mode==14:
        clean_pass()
elif mode==15:
        fix_font()
elif mode==16:
        fix_wizard()
elif mode==17:
        last_play()
elif mode==18:
        normal_metalliq()
elif mode==19:
        fast_metalliq()
elif mode==20:
        fix_buffer2()
elif mode==21:
        fix_buffer3()
elif mode==22:
        movie_update()
elif mode==23:
        skin_pfix()
elif mode==24:
        skin_efix()
elif mode==25:
        fix_buffer4()
if len(sys.argv)>0:

 xbmcplugin.endOfDirectory(int(sys.argv[1]))
