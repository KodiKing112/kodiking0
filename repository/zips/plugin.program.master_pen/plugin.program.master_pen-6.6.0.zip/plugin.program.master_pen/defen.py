parts=['aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQ=','LmNvbS9zaGltb25hci9zaC8=','bWFzdGVyLyVENyU5NCVENyVBMCVENyU5NSVENyVBNyVENyU5RA==','JTIwJUQ3JTk0JUQ3JUE4JUQ3JTkwJUQ3JUE5JUQ3JTk1JUQ3JTlGJTIwLnR4dA==']
cat_cat=True
year_cat=True
a_b_cat=True
ranking_cat=True
all_m_cat=True
cat_chan=True