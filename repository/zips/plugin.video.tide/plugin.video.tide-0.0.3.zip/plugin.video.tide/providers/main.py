import soccerstreams100

# list of providers
all_providers = [
    soccerstreams100
]
