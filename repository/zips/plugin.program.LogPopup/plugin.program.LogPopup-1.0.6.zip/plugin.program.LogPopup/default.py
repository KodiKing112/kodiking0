# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys
import traceback,pyxbmct
import logging,shutil
import HTMLParser,time
from shutil import copyfile



settings = xbmcaddon.Addon(id='plugin.program.LogPopup')
df = settings.getSetting("popup")
enable_debug_notice= settings.getSetting("debug")
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
def addDir( name, url, mode, iconimage='DefaultFolder.png'  , fanart='',summary='',isRealFolder=True):
        try:
           
            u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + str(mode) + "&name=" + name 
            liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
            liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name), "Plot": urllib.unquote(summary)})
            liz.setProperty('IsPlayable', 'false')
            if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
               
            ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=isRealFolder)
            if __DEBUG__:
                 
                print "added directory success:" + clean(contentType, name) + " url=" + clean('utf-8',u)
            return ok
        except Exception as e:
            print "WALLA exception in addDir"
            print e
            raise
     
def addDir2_2(name,url,mode,iconimage,fanart,description):

        uinstall_package=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        

        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
        
       # xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_LABEL)
        
   
        return ok
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok

def addDir2(name,url,mode,iconimage,fanart,description):
    u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
    ok=True
    liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
    liz.setInfo( type="Audio", infoLabels={ "Title": name } )
    if not fanart == '':
                liz.setProperty("Fanart_Image", fanart)
    ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=False)
    return ok
class POPUPTEXT(pyxbmct.AddonDialogWindow):
    def __init__(self, title='',text=[]):
        super(POPUPTEXT, self).__init__(title)
        self.setGeometry(1200, 700, 9, 4)
        self.text=text
        self.y=0
        self.x=len(text)-1
        self.changelog = pyxbmct.TextBox(font='Small')
        self.set_active_controls()
        self.connect(pyxbmct.ACTION_NAV_BACK, self.close)
        self.set_navigation()
        #self.changelog.controlUp(lambda:self.scroll_up)
    def fix_text(self,text):
      

      text_lines=text.splitlines()
      txt_all=''
      
      for line in text_lines:
        text_new1=line.strip()
        if ':' in text_new1:
         y=0
         text_new2=''
         for value in text_new1.split(':'):

           if y==0:
             text_new2=text_new2+'[COLOR aqua]'+value+'[/COLOR]'
           else:
             text_new2=text_new2+value
           y=y+1
         text_new=text_new2
        else:
         text_new=line
        txt_all=txt_all+text_new+'\n'
      return txt_all
    def next(self):
      if self.x<(len(self.text)-1):

        self.x=self.x+1
       
        new_text=self.fix_text(self.text[self.x])
        self.changelog.setText(new_text+'\n[COLOR lightblue]'+str(self.x)+'/'+str(len(self.text)-1)+'[/COLOR]')
    def prev(self):
     if self.x>0:
        
        self.x=self.x-1
      
        new_text=self.fix_text(self.text[self.x])
        self.changelog.setText(new_text+'\n[COLOR lightblue]'+str(self.x)+'/'+str(len(self.text)-1)+'[/COLOR]')
    def scroll_up(self):
       self.changelog.scroll(self.y)
       self.lines_count=sum(1 for line in self.text)

       if self.y<self.lines_count:
         self.y=self.y+1
    def scroll_down(self):
       self.changelog.scroll(self.y)
       if self.y>0:
         self.y=self.y-1
    def set_active_controls(self):
        
        new_text=self.fix_text(self.text[self.x])
        self.placeControl(self.changelog, 0, 0, 8, 8)
        self.changelog.setText(new_text+'\n[COLOR lightblue]'+str(self.x)+'/'+str(len(self.text)-1)+'[/COLOR]')
        self.connectEventList([pyxbmct.ACTION_MOVE_DOWN],
                              self.scroll_up)
        self.connectEventList([pyxbmct.ACTION_MOVE_UP],
                              self.scroll_down)


        # Button
        self.button5 = pyxbmct.Button('Next')
        self.placeControl(self.button5, 8, 1)
        # Connect control to close the window.
        self.connect(self.button5, self.next)
        
        self.button6 = pyxbmct.Button('Prev')
        self.placeControl(self.button6, 8, 0)
        # Connect control to close the window.
        self.connect(self.button6, self.prev)
        
        self.button7 = pyxbmct.Button('Close')
        self.placeControl(self.button7, 8, 3)
        # Connect control to close the window.
        self.connect(self.button7, self.close)
    def set_navigation(self):
      '''
      self.button5.controlUp(self.button6)
      self.button6.controlUp(self.button7)
      self.button7.controlUp(self.button5)
      self.button5.controlDown(self.button7)
      self.button6.controlDown(self.button5)
      self.button7.controlDown(self.button6)
      '''
      self.button5.controlLeft(self.button6)
      self.button6.controlLeft(self.button7)
      self.button7.controlLeft(self.button5)
      self.button5.controlRight(self.button7)
      self.button6.controlRight(self.button5)
      self.button7.controlRight(self.button6)
      
      self.setFocus(self.button5)
def main_menu(enable_debug_notice):
    nameSelect=[]
    logSelect=[]
    import glob
    folder = xbmc.translatePath('special://logpath')
    xbmc.log(folder)
    for file in glob.glob(folder+'/*.log'):
        try:nameSelect.append(file.rsplit('\\', 1)[1].upper())
        except:nameSelect.append(file.rsplit('/', 1)[1].upper())
        logSelect.append(file)
        
    
    file = open(logSelect[0], 'r') 
    home1=xbmc.translatePath("special://home/")
    home2=xbmc.translatePath("special://home/").replace('\\','\\\\')
    home3=xbmc.translatePath("special://xbmc/")
    home4=xbmc.translatePath("special://xbmc/").replace('\\','\\\\')
    home5=xbmc.translatePath("special://masterprofile/")
    home6=xbmc.translatePath("special://masterprofile/").replace('\\','\\\\')
    home7=xbmc.translatePath("special://profile/")
    home8=xbmc.translatePath("special://profile/").replace('\\','\\\\')
    home9=xbmc.translatePath("special://temp/")
    home10=xbmc.translatePath("special://temp/").replace('\\','\\\\')
    file_data=file.read().replace(home1,'').replace(home2,'').replace(home3,'').replace(home4,'').replace(home5,'').replace(home6,'').replace(home7,'').replace(home8,'').replace(home9,'').replace(home10,'')
    match=re.compile('Error Type:(.+?)-->End of Python script error report<--',re.DOTALL).findall(file_data)
    match2=re.compile('CAddonInstallJob(.+?)$', re.M).findall(file_data)
    match3=re.compile('ERROR: WARNING:root:(.+?)$', re.M).findall(file_data)
    n=0
    line_numbers=[]
    file = open(logSelect[0], 'r') 
    file_data=file.readlines() 
    match_final=[]
    x=0
    y=0
    z=0
    for  line in (file_data):
     
     if 'Error Type:' in line:
      match_final.append(match[x])
      x=x+1
      line_numbers.append(n)
     elif 'CAddonInstallJob' in line:
      match_final.append(match2[y])
      y=y+1
     elif 'ERROR: WARNING:root:' in line and enable_debug_notice=='true':
      match_final.append(match3[z])
      z=z+1
    
 
    if (len(match_final))>0:
      window = POPUPTEXT('Current Error',match_final)
      window.doModal()

      del window
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)

if mode==None or url==None or len(url)<1:
        main_menu(enable_debug_notice)


