# -*- coding: utf-8 -*-
#
#      Copyright (C) 2012 Tommy Winther
#      http://tommy.winther.nu

#  This Program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2, or (at your option)
#  any later version.
#
#  This Program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this Program; see the file LICENSE.txt.  If not, write to
#  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
#  http://www.gnu.org/copyleft/gpl.html
#

import xbmc,xbmcgui,xbmcaddon,os,time
import urllib,logging
import urllib2
import datetime
import config
import shutil
import gui, settings
import utils, base64
import sys
import threading
import re
from shutil import copytree
settings.setUrl()
idanDir = xbmc.translatePath('special://home/addons/plugin.video.idanplus/')
sys.path.insert(0, idanDir)
import resources.lib.common as common
import resources.lib.baseChannels as baseChannels
import resources.lib.epg as idanEpg


ADDONID = 'script.hebivueguide'
ADDON = xbmcaddon.Addon(ADDONID) 
Addon=ADDON
from threading import Timer
try:
    from sqlite3 import dbapi2 as database
except:
    from pysqlite2 import dbapi2 as database

user_dataDir = xbmc.translatePath(ADDON.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
cacheFile_epg = os.path.join(user_dataDir, 'master.db')

dbcon_epg = database.connect(cacheFile_epg)
dbcur_epg = dbcon_epg.cursor()
dbcur_epg.execute("CREATE TABLE IF NOT EXISTS %s ( ""id TEXT PRIMARY KEY, ""source TEXT, ""date TEXT, ""programs_updated TIMESTAMP);"%'updates')
dbcur_epg.execute("CREATE TABLE IF NOT EXISTS %s ( ""id TEXT PRIMARY KEY, ""source TEXT, ""date TEXT, ""programs_updated TIMESTAMP);"%'updates1')
dbcur_epg.execute("CREATE TABLE IF NOT EXISTS %s ( ""id TEXT PRIMARY KEY, ""channels_updated TIMESTAMP);"%'sources')
dbcur_epg.execute("CREATE TABLE IF NOT EXISTS %s ( ""id TEXT, ""title TEXT, ""logo TEXT, ""stream_url TEXT, ""source TEXT, ""visible BOOLEAN, ""weight INTEGER, PRIMARY KEY (id, source), FOREIGN KEY(source) REFERENCES sources(id) ON DELETE CASCADE);" % 'channels')
dbcur_epg.execute("CREATE TABLE IF NOT EXISTS %s ( ""channel TEXT, ""title TEXT, ""start_date TIMESTAMP, ""end_date TIMESTAMP, ""description TEXT, ""categories TEXT, ""image_large TEXT, ""image_small TEXT, ""season TEXT, ""episode TEXT, ""is_movie TEXT, ""date TEXT, ""language TEXT, ""source TEXT, ""updates_id INTEGER);" % 'programs')
dbcur_epg.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);')
dbcur_epg.execute('CREATE TABLE IF NOT EXISTS custom_stream_url(channel TEXT, stream_url TEXT);')
dbcur_epg.execute('CREATE TABLE IF NOT EXISTS version(major INTEGER, minor INTEGER,patch INTEGER);')
                # For notifications
dbcur_epg.execute("CREATE TABLE IF NOT EXISTS notifications(channel TEXT, channel_title TEXT, program_title TEXT, start_date TIMESTAMP, source TEXT, FOREIGN KEY(channel, source) REFERENCES channels(id, source) ON DELETE CASCADE)")



dbcon_epg.commit()

def GetUserChannels(type='tv'):
	userChannels = []
	if type == 'tv':
		channels = baseChannels.TvChannels
	elif type == 'radio':
		channels = baseChannels.RadioChannels
	for channel in channels:
		channel['index'] = common.GetIntSetting(channel['ch'], channel['index'])
	channels = sorted(channels, key=lambda k: k['index']) 
	for channel in channels:
		if channel['index'] != 0 and channel.get('type') != 'refresh':
			userChannels.append({'name': common.GetLocaleString(channel['nameID']), 'logo': 'special://home/addons/plugin.video.idanplus/resources/images/{0}'.format(channel['image']), 'link': 'plugin://plugin.video.idanplus/?url={0}&mode={1}&module={2}&moredata=best'.format(channel['channelID'], channel['mode'], channel['module']), 'tvgID': channel['tvgID'], 'index': channel['index']})
	userChannels = sorted(userChannels, key=lambda k: k['index'])
	return userChannels

channels = GetUserChannels(type='tv')

def ShowChannelEPG2(channel, name='', iconimage='', provider='auto', days=2):
    epg = idanEpg.GetEPG()
    if channel=='' or channel not in epg:
      return []
    now = int(time.time())
    day = ""
    programs = epg[channel]
    all_data=[]
    for program in programs:
        if now >= program['end']:
            continue
        startdate = datetime.datetime.fromtimestamp(program["start"]).strftime('%d/%m/%y')
        if startdate != day:
            day = startdate
            dayS = day
            
        start_time = program["start"]
        end_time = program["end"]
        programName = program["name"].strip().encode('utf-8')
        description = program["description"].strip().encode('utf-8')
        all_data.append(( channel,programName,start_time,end_time,description))
    return all_data
def _isProgramListCacheExpired():
    # check if data is up-to-date in database
   
    logging.warning('cheking_expire')
    
    date=datetime.datetime.now()
    dateStr = date.strftime('%Y-%m-%d')
    
    dbcur_epg.execute('SELECT programs_updated FROM updates1 WHERE source=? AND date=?', ['xmltv', dateStr])
    row = dbcur_epg.fetchone()
    logging.warning(row)
    today = datetime.datetime.now()
    logging.warning(type(today))
    logging.warning("row['programs_updated'].day")
  
    logging.warning( today.day)
    if row==None:
        return True
    db_day=datetime.datetime.fromtimestamp(row[0])
    logging.warning(db_day.day)
    expired = row is None or db_day.day != today.day
 
    return expired
def update_chan():
    logging.warning('updating')
    dbcur_epg.execute("DELETE FROM programs")
    dbcur_epg.execute("DELETE FROM updates1")
    dbcur_epg.execute("DELETE FROM channels")
    x=0

    for channel in channels:
        dbcur_epg.execute("SELECT * FROM channels WHERE id='%s'"%channel['name'])
        match=dbcur_epg.fetchone()
        if match==None:
            dbcur_epg.execute("INSERT INTO channels Values ('%s','%s','%s','%s','%s','%d','%d')"%(channel['name'], channel['name'], channel['logo'], channel['link'], 'xmltv', True, x))
        x+=1
        if 1:#try:
            alld=(ShowChannelEPG2(channel['tvgID']))
            
            for channel1,programName,start_time,end_time,description in alld:
               dbcur_epg.execute("INSERT INTO programs Values ('%s','%s','%d','%d','%s','%s','%s','%s','%s','%s','%s','%s','%s','%s','%d')"%( channel['name'],programName.replace("'",'%27'), int(start_time), int(end_time), description.replace("'",'%27') , '1', ' ', ' ', '', '', '', '', '', 'xmltv', 1))
        #except Exception as e:
        # logging.warning('eRORRROROROROROROROROOR')
        # logging.warning(e)
        # pass
        
    now_date=datetime.datetime.now().strftime('%Y-%m-%d')
    logging.warning(now_date)
    logging.warning(time.time())
    dbcur_epg.execute("INSERT INTO updates1 Values ('%s','%s','%s','%d')"%( '1','xmltv',str( now_date), int(time.time())))
    dbcon_epg.commit()

if _isProgramListCacheExpired():
    logging.warning('Expired')
    update_chan()

PACKAGES       = xbmc.translatePath(os.path.join('special://home', 'addons', 'packages'))
FORCE       = xbmc.translatePath(os.path.join('special://home', 'addons', 'script.hebivueguide', 'force.py'))
ivue = utils.folder()
skin = ADDON.getSetting('skin')
default = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'resources', 'skins', 'Default'))
setSkin = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'resources', 'skins', skin))

SkinFolder = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'resources', 'skins'))
iniPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'addons2.ini')) 
iniFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'addons.ini'))
catchupFile = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'resources', 'catchup.xml'))
catPath = xbmc.translatePath(os.path.join('special://profile', 'addon_data', 'script.hebivueguide', 'resources', 'categories'))
ivuecatsFile = xbmc.translatePath(os.path.join(catPath,'iVue.ini'))
customcatsFile = xbmc.translatePath(os.path.join(catPath,'custom.ini'))
addons_index_path = xbmc.translatePath('special://profile/addon_data/plugin.video.IVUEcreator/addons_index.ini')
ivueFile = ivue+'/categories.ini'
ivueINI = ivue+'/addons.ini'
ivueCatchup = ivue+'/catchup.xml'
skinsurl = ivue+'/skins/'
skinfiles = [] 
d = xbmcgui.Dialog()
dp = xbmcgui.DialogProgress()
interval = int(ADDON.getSetting('creator.interval'))



INTERVAL_ALWAYS = 0
INTERVAL_12 = 1
INTERVAL_24 = 2
INTERVAL_48 = 3
INTERVAL_72 = 4
INTERVAL_96 = 5
INTERVAL_120 = 6
INTERVAL_OFF = 7

if not os.path.exists(catPath):
    os.makedirs(catPath)

#Karls changes
def creator():
    if os.path.exists(iniPath) and os.path.exists(addons_index_path) and not interval == INTERVAL_OFF:
        if interval <> INTERVAL_ALWAYS:
            modTime = datetime.datetime.fromtimestamp(os.path.getmtime(iniPath))
            td = datetime.datetime.now() - modTime
            diff = (td.microseconds + (td.seconds + td.days * 24 * 3600) * 10 ** 6) / 10 ** 6
            if ((interval == INTERVAL_12 and diff >= 43200) or
                    (interval == INTERVAL_24 and diff >= 86400) or
                    (interval == INTERVAL_48 and diff >= 172800) or
                    (interval == INTERVAL_72 and diff >= 259200) or
                    (interval == INTERVAL_96 and diff >= 345600) or
                    (interval == INTERVAL_120 and diff >= 432000)):
                xbmc.executebuiltin('RunPlugin(plugin://plugin.video.IVUEcreator/update)')
            else:
                w = gui.TVGuide()
                w.doModal()
                del w
        else:
            xbmc.executebuiltin('RunPlugin(plugin://plugin.video.IVUEcreator/update)')
    else:
        w = gui.TVGuide()
        w.doModal()
        del w


#End of Karls changes


try:
    if os.path.exists(FORCE) and os.path.exists(SkinFolder):
        viewskins = config.openURL(skinsurl)
        matchskin =re.compile('<a href="(.*?)">').findall(viewskins)
        for name in matchskin:
            name = re.sub(r'%20', ' ', name)
            name = re.sub(r'.zip', '', name)
            if name in os.listdir(SkinFolder):
                shutil.rmtree(os.path.join(SkinFolder, name))
        url = ivue+'/skins/skins.zip'
        zipfile = os.path.join(PACKAGES,"skins.zip") 
        dp.create("iVue","Downloading latest Skin Pack",'')
        urllib.urlretrieve(url,zipfile,lambda nb, bs, fs, url=url: config._pbhook(nb,bs,fs,url,dp))
        config.extract(zipfile, SkinFolder)
        time.sleep(1)
        os.remove(FORCE)
        ADDON.setSetting('scroll.chan', 'Enabled')
        ADDON.setSetting('font', 'Disabled')
        import reset
        reset.SoftReset()
        dp.close() 
    elif os.path.exists(FORCE) and not os.path.exists(SkinFolder):
        os.remove(FORCE)

    if not os.path.exists(default):
        url = ivue+'/skins/Default.zip'
        zipfile = os.path.join(PACKAGES,"default.zip") 
        dp.create("iVue","Downloading Default Skin",'')
        urllib.urlretrieve(url,zipfile,lambda nb, bs, fs, url=url: config._pbhook(nb,bs,fs,url,dp))
        config.extract(zipfile, SkinFolder)
        ADDON.setSetting('scroll.chan', 'Enabled')
        ADDON.setSetting('font', 'Disabled')
        time.sleep(1)
        dp.close() 
 
    if not os.path.exists(setSkin):
        try:
            url = ivue+'/skins/%s.zip' %(skin).replace (" ","%20") 
            urllib2.urlopen(url)
            zipfile = os.path.join(PACKAGES,"%s.zip" % skin) 
            dp.create("iVue","Downloading %s" % skin,'')
            urllib.urlretrieve(url,zipfile,lambda nb, bs, fs, url=url: config._pbhook(nb,bs,fs,url,dp))
            config.extract(zipfile, SkinFolder)
            ADDON.setSetting('scroll.chan', 'Enabled')
            ADDON.setSetting('font', 'Disabled')
            time.sleep(1)
            dp.close() 
        except urllib2.HTTPError, e:
            ADDON.setSetting('skin', 'Default')
            ADDON.setSetting('font', 'Disabled')
            ADDON.setSetting('scroll.chan', 'Enabled')
            pass

    if ADDON.getSetting('ivue.addons.ini') == 'true':
        dp.create("iVue","Downloading files",'')
        try:
            urllib.urlretrieve(ivueINI,iniFile,lambda nb, bs, fs, url=ivueINI: config._pbhook(nb,bs,fs,url,dp))
        except:
            pass
        try:
            urllib.urlretrieve(ivueCatchup,catchupFile,lambda nb, bs, fs, url=ivueCatchup: config._pbhook(nb,bs,fs,url,dp))
        except:
            pass
        try:
            urllib.urlretrieve(ivueFile,ivuecatsFile,lambda nb, bs, fs, url=ivueFile: config._pbhook(nb,bs,fs,url,dp))
        except:
            pass
        dp.close()
        ADDON.setSetting('ivue.addons.ini', 'false')

    if not os.path.exists(iniFile):
        dp.create("iVue","Downloading addons.ini",'')
        urllib.urlretrieve(ivueINI,iniFile,lambda nb, bs, fs, url=ivueINI: config._pbhook(nb,bs,fs,url,dp))
        dp.close()


    if not os.path.exists(catchupFile):
        dp.create("iVue","Downloading catchup.xml",'')
        urllib.urlretrieve(ivueCatchup,catchupFile,lambda nb, bs, fs, url=ivueCatchup: config._pbhook(nb,bs,fs,url,dp))
        dp.close()


    if not os.path.exists(ivuecatsFile):
        dp.create("iVue","Downloading categories file",'')
        urllib.urlretrieve(ivueFile,ivuecatsFile,lambda nb, bs, fs, url=ivueFile: config._pbhook(nb,bs,fs,url,dp))
        dp.close()

except:
    d.ok('iVue Server Notice', 'Looks like we Couldnt connect to the iVue server.', 'Please check your internet connection (iVue maybe offline).', 'Guide may not work properly in the mean time')
    

try:
    if ADDON.getSetting('categories.ini.enabled') == 'true':
        if ADDON.getSetting('categories.ini.type') == '0':
            if not ADDON.getSetting('categories.ini.file') == '':
                customFile = str(ADDON.getSetting('categories.ini.file'))
                shutil.copy(customFile, customcatsFile)
                ADDON.setSetting('categories.ini.enabled', 'false')
        else:
            customURL = str(ADDON.getSetting('categories.ini.url')) 
            urllib.urlretrieve(customURL, customcatsFile)
            ADDON.setSetting('categories.ini.enabled', 'false')
except:
    d.ok('iVue Notice', 'Looks like we Couldnt retrieve your custom categories file', 'Please check your file path or internet connection if using url', 'iVue may not work properly in the mean time')
    pass




#addons ini fix start

# set filepath
addons_data_ini_path = xbmc.translatePath('special://profile/addon_data/plugin.video.IVUEcreator/addons_index.ini')
old_ini_path = xbmc.translatePath('special://home/addons/plugin.video.IVUEcreator/addons_index.ini')

if os.path.exists(old_ini_path):
    shutil.move(old_ini_path, addons_data_ini_path)
#addons ini end

try:
	runType = len(sys.argv)    
	if interval == INTERVAL_OFF:	        
	    w = gui.TVGuide()
	    w.doModal()
	    del w
	elif not interval == INTERVAL_OFF and runType == 1:
	    creator()
	elif not interval == INTERVAL_OFF and runType > 1:
	    w = gui.TVGuide()
	    w.doModal()
	    del w


except urllib2.HTTPError, e:
		utils.notify(addon_id, e)