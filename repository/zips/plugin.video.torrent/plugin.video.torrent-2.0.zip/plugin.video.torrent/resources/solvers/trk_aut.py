# -*- coding: utf-8 -*-
import requests,re,urllib,logging,sys

def auto_trk_auth(key):
        import xbmcgui,xbmcaddon
        Addon = xbmcaddon.Addon()
        dp = xbmcgui . DialogProgress ( )
        dp.create('אנא המתן','מאשר אנא המתן', key,'')
        dp.update(0, 'אנא המתן','מאשר אנא המתן', key )
        user=Addon.getSetting("trk_user")
        passward=Addon.getSetting("trk_pass")
        cookies = {
            'user_data_version': '3',
        }

        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        response = requests.get('https://trakt.tv/auth/signin', headers=headers, cookies=cookies)
        regex='name="csrf-token" content="(.+?)"'
        m=re.compile(regex).findall(response.content)[0]
        cookies = {
            'user_data_version': '3',
            
            'webp_supported': 'true',
            'watchnow_country': 'il',
            '_traktsession':response.cookies['_traktsession'],
            
          
        }
  
        dp.update(0, 'אנא המתן','נכנס לחשבון', user )
        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Origin': 'https://trakt.tv',
            'Upgrade-Insecure-Requests': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/auth/signin',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        data = {
          'utf8': '\u2713',
          'authenticity_token': m,
          'user[login]': user,
          'user[password]': passward,
          'user[remember_me]': '1'
        }

        response = requests.post('https://trakt.tv/auth/signin', headers=headers, cookies=cookies, data=data)
        
        regex='id="meta-username" type="hidden" value="(.+?)"'
        user_n=re.compile(regex).findall(response.content)
        if len(user_n)==0:
            xbmcgui.Dialog().ok('שגיאה','בדוק שם משתמש וסיסמא')
            sys.exit()
        else:
            user_n=user_n[0]
        logging.warning('user_n:'+user_n)
        
        regex='name="csrf-token" content="(.+?)"'
        m=re.compile(regex).findall(response.content)[0]
        us_token=response.cookies['remember_user_token']
        cookies = {
            'user_data_version': '3',
          
            'webp_supported': 'true',
            'watchnow_country': 'il',
            
            '_gat': '1',
            '_gali': 'new_user',
            'trakt_username': user_n,
            'trakt_userslug': user_n.lower(),
            'remember_user_token':us_token,
            '_traktsession':response.cookies['_traktsession'],
        }

        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/auth/signin',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        response = requests.get('https://trakt.tv/activate', headers=headers, cookies=cookies)
       
        dp.update(0, 'אנא המתן','מפעיל', user )
        m=re.compile(regex).findall(response.content)[0]

        cookies = {
            'user_data_version': '3',
          
            'webp_supported': 'true',
            'watchnow_country': 'il',
           
            '_gat': '1',
            'trakt_username': user_n,
            'trakt_userslug': user_n.lower(),
            'remember_user_token':us_token,
            '_traktsession':response.cookies['_traktsession'],
        }

        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Origin': 'https://trakt.tv',
            'Upgrade-Insecure-Requests': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/activate',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        data = {
          'utf8': '\u2713',
          'authenticity_token': m,
          'code': key,
          'commit': 'Continue'
        }

        response = requests.post('https://trakt.tv/activate', headers=headers, cookies=response.cookies, data=data)
        m=re.compile(regex).findall(response.content)[0]
        


        headers = {
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
            'Origin': 'https://trakt.tv',
            'Upgrade-Insecure-Requests': '1',
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Referer': 'https://trakt.tv/activate/authorize',
            'Accept-Encoding': 'utf-8',
            'Accept-Language': 'en-US,en;q=0.9',
        }

        data = {
          'utf8': '\u2713',
          'authenticity_token': m,
          'commit': 'Yes'
        }

        response = requests.post('https://trakt.tv/activate/authorize', headers=headers, cookies=response.cookies, data=data)
        logging.warning(response.cookies)
        logging.warning(response.headers)
        #logging.warning(response.content)
        dp.close()