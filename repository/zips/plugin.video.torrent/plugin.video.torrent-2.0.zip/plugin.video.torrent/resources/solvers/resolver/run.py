# -*- coding: utf-8 -*-
import os,sys,urllib2
import mediaurl,urlparse
import  threading
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
dir_path = os.path.dirname(os.path.realpath(__file__))
mypath=os.path.join(dir_path,'..')
sys.path.append(mypath)
mypath=os.path.join(dir_path,'..\..\done')
sys.path.append(mypath)
class Thread(threading.Thread):
    def __init__(self, target, *args):
       
        self._target = target
        self._args = args
        
        
        threading.Thread.__init__(self)
        
    def run(self):
        
        self._target(*self._args)
import requests,re,sys,logging,urllib,json,time,cache
from general import domain_s,cloudflare_request,base_header
try:
  import xbmcgui,xbmc
  local=False
except:
  local=True
global tv_mode
###############################streamango##############################
def streamango_decode(encoded, code):
        #from https://github.com/jsergio123/script.module.urlresolver
        _0x59b81a = ""
        k = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='
        k = k[::-1]

        count = 0

        for index in range(0, len(encoded) - 1):
            while count <= len(encoded) - 1:
                _0x4a2f3a = k.index(encoded[count])
                count += 1
                _0x29d5bf = k.index(encoded[count])
                count += 1
                _0x3b6833 = k.index(encoded[count])
                count += 1
                _0x426d70 = k.index(encoded[count])
                count += 1

                _0x2e4782 = ((_0x4a2f3a << 2) | (_0x29d5bf >> 4))
                _0x2c0540 = (((_0x29d5bf & 15) << 4) | (_0x3b6833 >> 2))
                _0x5a46ef = ((_0x3b6833 & 3) << 6) | _0x426d70
                _0x2e4782 = _0x2e4782 ^ code

                _0x59b81a = str(_0x59b81a) + chr(_0x2e4782)

                if _0x3b6833 != 64:
                    _0x59b81a = str(_0x59b81a) + chr(_0x2c0540)
                if _0x3b6833 != 64:
                    _0x59b81a = str(_0x59b81a) + chr(_0x5a46ef)

        return _0x59b81a
        

def resolve_streamango(url):
        api_call=False
        headers = {
        'Pragma': 'no-cache',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.9',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        }   

        sHtmlContent= requests.get(url,headers=headers).content
        regex="\"video/mp4\",src:d\('(.+?)',(.+?)\)"
        match=re.compile(regex).findall(sHtmlContent)
        code1,code2=match[0]
        #r1 = re.search("srces\.push\({type:\"video/mp4\",src:d\('([^']+)',(\d+)", sHtmlContent)
     
        
        if (match):
            api_call = streamango_decode(code1, int(code2))
            if api_call.endswith('@'):
              api_call=api_call[:-1]
            api_call = 'http:' + api_call
       
 
            return api_call
###############################Streamango END##############################

###############################Thevideo##############################

def resolve_thevideo(url):
    headers = {
   
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.5',
   
    'Content-Type': 'application/json;charset=utf-8',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
}
    x=requests.get(url,headers=headers,verify=False)
    logging.warning( x.url)
    headers = {
    'Host': 'vev.io',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': x.url,
    'Content-Type': 'application/json;charset=utf-8',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    regex='"video_code":"(.+?)"'
    match=re.compile(regex).findall(x.content)
    
    response = requests.post('https://vev.io/api/serve/video/'+match[0], headers=headers, verify=False).json()
    all_q=[]
    all_links=[]
    for items in response['qualities']:
       all_q.append(items)
       all_links.append(response['qualities'][items])
    ret=xbmcgui.Dialog().select("בחר איכות", all_q)
    if ret==-1:
        sys.exit()
    else:
        return all_links[ret]
###############################Thevideo END##############################
###############################Upfile ##############################
def get_upfile_det(url):
    name=''
    headers = {
  
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
    'Accept': 'application/json',
    'Accept-Language': 'en-US,en;q=0.5',
    
    'Content-Type': 'application/json;charset=utf-8',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    html=requests.get(url,headers=headers).content
    regex='<title>(.+?)</title>.+?<input type="hidden" value="(.+?)" name="hash">'
    match=re.compile(regex,re.DOTALL).findall(html)

    for name,link in match:
      id=url.split('/')[-1]
      id=id.replace('.html','').replace('.htm','')
      
      playlink='http://down.upfile.co.il/downloadnew/file/%s/%s'%(id,link)
    return playlink
    
def fix_sratim_link(url):
        import xbmcaddon
        Addon = xbmcaddon.Addon()
        regex='sratim-il.com/(.+?).mp4'
        class cok:
           name=''
           value=''
        match=re.compile(regex).findall(url)
        x=requests.get(url.replace('.mp4','')+'/',verify=False).cookies
        regex='//(.+?)/'
        host=re.compile(regex).findall(url)[0]
        for cok in x:
          logging.warning(cok.name)
          logging.warning(cok.value)
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
            'Accept-Language': 'en-US,en;q=0.5',
            #'Referer':'https://www.sratim.co/'+match[0],
            'Host': host,
            'Cookie': '%s=%s'%(cok.name,cok.value),
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        ref=Addon.getSetting("sratim_url")
        headers = {
            'Referer':'https://%s/'%ref+urllib.unquote_plus(match[0]),
            'Accept-Encoding': 'identity;q=1, *;q=0',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36',
            
            'chrome-proxy': 'frfr',
        }
        '''
        headers={'Accept':'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
                'Accept-Language':'en-US,en;q=0.5',
                'Cache-Control':'no-cache',
                'Connection':'keep-alive',
                #'Host':'server2.sratim-il.com',
                'Pragma':'no-cache',

                'Referer':'http://www.sratim-il.cf/newsite/%s/'%match[0],
                'User-Agent':'Mozilla/5.0 (Windows NT 6.1; W…) Gecko/20100101 Firefox/59.0'}
        '''
        head=urllib.urlencode(headers)
        url=url+"|"+head
        return url
        
def get_lats(url):

         headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://letsupload.co/search.html',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
         }
         regex='https://letsupload.co/(.+?)/'
         m=re.compile(regex).findall(url)[0]
         
         u='http://letsupload.co/plugins/mediaplayer/site/_embed.php?u=%s&w=1920&h=1080'%m
         
         ur2,cookie=cloudflare_request(u, headers=headers)
         regex='file: "(.+?)"'
         match=re.compile(regex).findall(ur2)
         if len (match)==0:
            regex='<embed.+?src="(.+?)"'
            url=re.compile(regex,re.DOTALL).findall(ur2)[0]
         else:
            url=match[0]
         return url
def get_vcstream(url):
                headers = {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:61.0) Gecko/20100101 Firefox/61.0',
                    'Accept': 'application/json, text/javascript, */*; q=0.01',
                    'Accept-Language': 'en-US,en;q=0.5',
              
                    'X-Requested-With': 'XMLHttpRequest',
                    'Connection': 'keep-alive',
                    'Pragma': 'no-cache',
                    'Cache-Control': 'no-cache',
                 }
                x=requests.get(url,headers=headers).content
                regex="fileID = '(.+?)'"
                id=re.compile(regex).findall(x)[0]
                
              
                yy=requests.get('https://vcstream.to/player?fid=%s&page=embed'%id).json()
                
            
                if 'player.updateSrc' in yy['html']:
                  regex='player.updateSrc\((.+?)\)'
                  match=json.loads(re.compile(regex).findall(yy['html'])[0])
                elif 'sources' in yy['html']:
                  regex='sources =(.+?)]'
                  match=json.loads(re.compile(regex).findall(yy['html'])[0]+']')
                all_q=[]
                all_links=[]
                logging.warning(match)
                if 'file' in match[0]:
                    return match[0]['file']
                for items in match:
                  all_q.append(items['name']+' - '+items['label'])
                  all_links.append(items['src'])
                if len (all_q)==1:
                      url=all_links[0]
                      name=all_q[0].split(' - ')[0]
                else:
                    try:
                        ret=xbmcgui.Dialog().select("בחר סוג", all_q)
                        if ret==-1:
                            sys.exit()
                        else:
                          url=all_links[ret]
                          name=all_q[ret].split(' - ')[0]
                    except:
                       url=all_links[0]
                       name=all_q[0].split(' - ')[0]
                return url
def get_req(url):
    headers = {
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
    }
    x=requests.get(url,headers=headers).content
    
   
    
    regex='name="_method" value="POST"/>.+?_csrfToken".+?value="(.+?)".+?"ad_form_data".+?value="(.+?)".+?"_Token\[fields\]".+?value="(.+?)".+?"_Token\[unlocked\]".+?value="(.+?)"'
    match=re.compile(regex,re.DOTALL).findall(x)
    csrtoken,ad_form_data,Token_fields,Token_unlocked=match[0]

    time.sleep(5.1)
    cookies = {
        
        'csrfToken': csrtoken,
        
    }

    headers = {
        'Pragma': 'no-cache',
        'Origin': 'http://reqlinks.net',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.79 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        'Referer': url,
    }

    data = [
      ('_method', 'POST'),
      ('_csrfToken', csrtoken),
      ('ad_form_data', str(ad_form_data.strip())),
      ('_Token[fields]', Token_fields),
      ('_Token[unlocked]', Token_unlocked),
    ]

    response = requests.post('http://reqlinks.net/links/go', headers=headers, cookies=cookies, data=data).json()
    logging.warning(response)
   
    return (response['url'])
def get_final_video_and_cookie(sid, season, episode, choose_quality=False, download=False):
    from sdarot import get_sdarot_ck,get_sdarot_ck,get_video_url
    import Addon
    #get_sdarot_ck(sid,season,episode)
    token,cookie=cache.get(get_sdarot_ck,3,sid,season,episode, table='cookies')
    logging.warning('sd cookie')
    logging.warning(cookie)
   
    logging.warning('sd cookie2')
    logging.warning('Doner Test:'+token)
    logging.warning(cookie)
    #cookie={'Sdarot':'FOcYpGHLb'}
    if cookie=={} or token == 'donor':
        logging.warning('Get donor')
        token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode,cookie, table='cookies')
        logging.warning('Doner Test22:'+token)
        logging.warning(cookie)
    else:
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
        logging.warning('sd vid')
        logging.warning(vid)
        if 'errors' not in vid:
             return vid, cookie
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Torrent', vid['errors'][0])).encode('utf-8'))
            
        if 'uid=|Co' in vid:
           
            token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode, table='cookies')
          
        else:
           
 
           
           if 'errors' not in vid:
             return vid, cookie
    logging.warning(token)
    if token == 'donor':
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)

    else:
        if download:
            #plugin.notify('התחבר כמנוי כדי להוריד פרק זה', image=ICON)
            return None, None
        else:
            vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
            if 'errors' in vid:
                msg="אנא המתן 30 שניות"#vid['errors'][0]
            else:
                msg="אנא המתן 30 שניות"
            if not local:
                
                dp = xbmcgui.DialogProgress()
                dp.create("לצפייה באיכות HD וללא המתנה ניתן לרכוש מנוי", msg, vid['errors'][0],
                          "[COLOR orange][B]לרכישת מנוי להיכנס בדפדפן - www.sdarot.tv/donate[/B][/COLOR]")
                dp.update(0)
            tm=31
   
            if not 'errors' in vid:
             tm=0
         
             return vid, cookie
            else:
                
                tm=re.findall(r' \d+ ', vid['errors'][0])
                if len(tm)==0:
                    if Addon.getSetting("new_window_type2")=='3' or Addon.getSetting("new_window_type2")=='4':
                       xbmc.executebuiltin((u'Notification(%s,%s)' % ('Torrent', vid['errors'][0])).encode('utf-8'))
                       return None, None
                    else:
                        xbmcgui.Dialog().ok('Sdaror TV',vid['errors'][0])
                        sys.exit()
                tm=int (tm[0].strip())
                if tm>28:
                    token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode, table='cookies')
                    tm=30
            
            
            
            

            for s in range(tm, -1, -1):
                time.sleep(1)
                if  local:
                    sys.stdout.write("\r עוד {0} שניות".format(s))
                    sys.stdout.flush()
                else:
                    dp.update(int((tm - s) / (tm+1) * 100.0), msg, 'עוד {0} שניות'.format(s), '')
                    if dp.iscanceled():
                        dp.close()
                        return None, None
        

        
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
        logging.warning('VID LINK')
        if Addon.getSetting("new_window_type2")=='3' or Addon.getSetting("new_window_type2")=='4':

            if 'errors' in vid:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('Torrent', vid['errors'][0])).encode('utf-8'))
                return None, None
        else:
            if 'errors' in vid:
                    xbmcgui.Dialog().ok('Sdaror TV',vid['errors'][0])
                    sys.exit()
    if vid:
           
            return vid, cookie
def decrypt(url):
    from base64 import b64decode
    ''' decrypt the given encrypted code '''
    html=requests.get(url).content
    

    regex="var ysmm = '(.+?)'"
    match=re.compile(regex).findall(html)
    if len(match)>0:
        
        ysmm = match[0]
      
        #ysmm='Y=jMkDyNM3GUUD1MYwzIJWiNYx2UZmmNOkTVcDyMMi2Rh20Yd6HIAT6MLiyN9G0Nd33McTuZdymMljkYZvWU9G3bZpWZV1kLLzmV'
        code=(ysmm.decode('utf-8'))

        zeros, ones = '', ''

        for num, letter in enumerate(code):
            if num % 2 == 0: zeros += code[num]
            else: ones = code[num] + ones

        key = zeros + ones
 
        u=list((key))
 
        m=0
        while m <(len(u)-1):
          if u[m].isnumeric():
              R=m+1
              while R< (len(u)-1): 
                if u[R].isnumeric():
                     
                  S =(int(u[m]) ^ int(u[R]))


                  if ((S) < 10):

                    u[m] = unicode(S)
                  m = R
                  R = len(u)
                R=R+1
          m=m+1
        t3="".join(u)

        key = (t3).decode('base64')

        key=key[(len(t3)-(len(t3)-16)):]
 
        key=key[:((len(key)-16))]
    else:
      from unshort import unshorten
 
     
      unshortened_uri, status = unshorten(url,type='shst')

      if unshortened_uri==url:
        unshortened_uri, status = unshorten(url,type='shst')
      key=unshortened_uri
     
   
    return key
def get_sdarot(url):
       from sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
       '''
       regex='https://(.+?)/'
       match=re.compile(regex).findall(url)
       h=(MyResolver(match[0]))
       url=url.replace(match[0],h)
       '''
       return url

def get_vidup(url):
    logging.warning('Resolve vidup')
    from vidup import getMediaLinkForGuest
    url=requests.get(url,headers=base_header).url
    logging.warning(url)
    url=getMediaLinkForGuest(url)
    return url

    
 
def resolve_flashx(url):
    from flashx import __getMediaLinkForGuest
    link=__getMediaLinkForGuest(url)

    return link[1]
def get_vidshare(url,embed=False):
    
    if not embed:
        url=url.replace('http:','https:')
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': url,
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        x=requests.get(url,headers=headers).content
        
        regex='name="op" value="(.+?)".+?name="id" value="(.+?)".+?name="fname" value="(.+?)"'
        match=re.compile(regex,re.DOTALL).findall(x)
        if len(match)>0:
            data = {
              'op': match[0][0],
              'usr_login': '',
              'id': match[0][1],
              'fname': match[0][2],
              'referer': '',
              'method_free': 'Proceed to video'
            }
            
            logging.warning(data)
            html = requests.post(url, headers=headers, data=data).content#'https://vshare.eu/w47ap9si9f6l.htm'
            
        else:
            regex='eval(.+?)\n'
            match=re.compile(regex).findall(x)
            
            from jsunpack import unpack
            res=(unpack('eval'+match[0])).replace('$("#videojs").append','result=')
            from js2py.internals import seval
            result2=seval.eval_js_vm(res)
            logging.warning(result2)
            reges='source src="(.+?)"'
            match=re.compile(reges,re.DOTALL).findall(result2)[0]
            return match
    else:
        headers = {
            'Pragma': 'no-cache',
            
            'Accept-Encoding': 'utf8',
            'Accept-Language': 'en-US,en;q=0.9',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Cache-Control': 'no-cache',
            'X-Requested-With': 'XMLHttpRequest',
            'Connection': 'keep-alive',
            
        }
        html=requests.get(url,headers=headers).content
    regex='source src="(.+?)"'
    match=re.compile(regex).findall(html)[0]
    return match
def get_viooz(url):
        headers = {
        
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
       
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
        x=requests.get(url,headers=headers).content
        regex='getinfo\("(.+?)"'
        match=re.compile(regex).findall(x)
       
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36',
            'Referer': url,
            'Origin': 'https://viooz.fun',
        }
        y=requests.get('https://hdv.fun/1-a.php?a='+match[0],headers=headers).json()
      
       
        
        path=y['webseed'].split('u=')[0]+'u='+urllib.quote_plus(y['webseed'].split('u=')[1])
        url='https://torrent.hdv.fun/m3u8.php?i=%s&u=%s'%(y['id'],path)
        return url
def get_ganol(url):
        from general import server_data
        from jsunpack import unpack
        headers = {
        #'Host': 'ganool.im',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:60.0) Gecko/20100101 Firefox/60.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        #'Referer': 'https://ganool.im/?s=black+panther',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        }
        x=requests.get(url,headers=headers).content
        regex='IFRAME.+?SRC="(.+?)"'
        match=re.compile(regex,re.IGNORECASE).findall(x)
        names_urls=[]
        urls=[]
        resolvea=[]
        for item in match:
          logging.warning(item)
          if 'blazefile.co' in item:
             try:
                 
                 y=requests.get(item).content
                 regex="type='text/javascript'>(.+?)<"
                 match_in=re.compile(regex,re.DOTALL).findall(y)
                 temp=unpack(match_in[0])
           
                 regex_link='file:"(.+?)"'
                 match_link=re.compile(regex_link).findall(temp)[0]
                 regex_n='//(.+?)/'
                 match_n=re.compile(regex_n).findall(match_link)[0]
                 names_urls.append(match_n)
                 urls.append(match_link)
                 resolvea.append(False)
             except:
              pass
          elif 'youtube' not in item and 'http' in item:
             
             regex_n='//(.+?)/'
             match_n=re.compile(regex_n).findall(item)[0]
             
             name1,match_s,res,check=server_data(item,match_n)
             if check:
               names_urls.append(match_n)
               resolvea.append(True)
               urls.append(item)
        if local:
            return url
        else:
            if len(urls)>1:
                ret=xbmcgui.Dialog().select("בחר שרת", names_urls)
                if ret==-1:
                    sys.exit()
                else:
                   url=urls[ret]
                   resolvable=resolvea[ret]
            else:
               if len(urls)==0:
                xbmcgui.Dialog().ok('Error occurred','אין לינקים תקינים')
                sys.exit()
               else:
                url=urls[0]
            return url
def get_uptobox(url):

    global tv_mode
    import uptobox
    upto = uptobox.cHoster()
    s_url=upto.setUrl(url)
    s_url=upto.getMediaLink()
    logging.warning(s_url)
    return s_url
    
    if 'uptostream' not in url:
        x=requests.get(url).content
        regex='<a href="https://uptostream.com/(.+?)"'
        match=re.compile(regex).findall(x)

    
        url=domain_s+'uptostream.com/'+match[0]
    
    
    

    cookies = {
        #'__cfduid': 'd0dfe3eedd616e0f275edcea08cdb6e521520582950',
        'video': '55srlypu0c08',
    }

    headers = {
        'Host': 'uptostream.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    response = requests.get(url, headers=headers, cookies=cookies,timeout=10).content
    regex='var sources = (.+?);'
    match=re.compile(regex).findall(response)
    logging.warning(match)
    if len(match)==0:
      regex="sources \= JSON.parse\('(.+?)'"
      match=re.compile(regex).findall(response)
    if len(match)==0:
      regex="sources = JSON.parse\(atob\('(.+?)'"
      match=re.compile(regex).findall(response)
      logging.warning('m2')
      logging.warning(match)
      links=json.loads(match[0].decode('base64'))
    else:
        links=json.loads(match[0])
    quality=[]
    links2=[]
    for data in links:
      quality.append(int(data['label'].replace('p','')))
      links2.append(data['src'])
    if local==True or tv_mode:
       return links2[0]
    else:
        return links2[quality.index(max(quality))]
        ret = xbmcgui.Dialog().select("בחר איכות", quality)
        if ret!=-1:
            f_link=links2[ret]
        else:
          return 0
        return f_link
def getPublicStream(url):
        import cookielib
        

        pquality=-1
        pformat=-1
        acodec=-1

        mediaURLs = []
  
       
        cookies = cookielib.LWPCookieJar()
        handlers = [
            urllib2.HTTPHandler(),
            urllib2.HTTPSHandler(),
            urllib2.HTTPCookieProcessor(cookies)
            ]
        opener = urllib2.build_opener(*handlers)
        req = urllib2.Request(url)

        req.add_header('User-agent',__USERAGENT__)
        result= opener.open(req)
        for cookie in cookies:
            if cookie.name=='DRIVE_STREAM':
              value=cookie.value

        #response = urllib2.urlopen(req)
        
        response_data = result.read()
        #response.close()
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }

        response_data = requests.get(url, headers=headers, cookies=cookies).content



        fmtlist=None
        for r in re.finditer('\"fmt_list\"\,\"([^\"]+)\"' ,
                             response_data, re.DOTALL):
            fmtlist = r.group(1)
        if not fmtlist:
            logging.warning(response_data)
            fmtlist = re.compile('"fmt_list","(.+?)"').findall(response_data)
        title = ''
        for r in re.finditer('\"title\"\,\"([^\"]+)\"' ,
                             response_data, re.DOTALL):
            title = r.group(1)

        logging.warning('fmtlist')
        logging.warning(fmtlist)
        itagDB={}
        containerDB = {'x-flv':'flv', 'webm': 'WebM', 'mp4;+codecs="avc1.42001E,+mp4a.40.2"': 'MP4'}
        for r in re.finditer('(\d+)/(\d+)x(\d+)/(\d+/\d+/\d+)\&?\,?' ,
                               fmtlist, re.DOTALL):
              (itag,resolution1,resolution2,codec) = r.groups()

              if codec == '9/0/115':
                itagDB[itag] = {'resolution': resolution2, 'codec': 'h.264/aac'}
              elif codec == '99/0/0':
                itagDB[itag] = {'resolution': resolution2, 'codec': 'VP8/vorbis'}
              else:
                itagDB[itag] = {'resolution': resolution2}

        for r in re.finditer('\"url_encoded_fmt_stream_map\"\,\"([^\"]+)\"' ,
                             response_data, re.DOTALL):
            urls = r.group(1)


        
        urls = urllib.unquote(urllib.unquote(urllib.unquote(urllib.unquote(urllib.unquote(urls)))))
        urls = re.sub('\\\\u003d', '=', urls)
        urls = re.sub('\\\\u0026', '&', urls)


#        urls = re.sub('\d+\&url\='+self.PROTOCOL, '\@', urls)
        urls = re.sub('\&url\='+ 'https://', '\@', urls)

#        for r in re.finditer('\@([^\@]+)' ,urls):
#          videoURL = r.group(0)
#        videoURL1 = self.PROTOCOL + videoURL


        # fetch format type and quality for each stream
        count=0
        
        for r in re.finditer('\@([^\@]+)' ,urls):
                videoURL = r.group(1)
                for q in re.finditer('itag\=(\d+).*?type\=video\/([^\&]+)\&quality\=(\w+)' ,
                             videoURL, re.DOTALL):
                    (itag,container,quality) = q.groups()
                    count = count + 1
                    order=0
                    if pquality > -1 or pformat > -1 or acodec > -1:
                        if int(itagDB[itag]['resolution']) == 1080:
                            if pquality == 0:
                                order = order + 1000
                            elif pquality == 1:
                                order = order + 3000
                            elif pquality == 3:
                                order = order + 9000
                        elif int(itagDB[itag]['resolution']) == 720:
                            if pquality == 0:
                                order = order + 2000
                            elif pquality == 1:
                                order = order + 1000
                            elif pquality == 3:
                                order = order + 9000
                        elif int(itagDB[itag]['resolution']) == 480:
                            if pquality == 0:
                                order = order + 3000
                            elif pquality == 1:
                                order = order + 2000
                            elif pquality == 3:
                                order = order + 1000
                        elif int(itagDB[itag]['resolution']) < 480:
                            if pquality == 0:
                                order = order + 4000
                            elif pquality == 1:
                                order = order + 3000
                            elif pquality == 3:
                                order = order + 2000
                    try:
                        if itagDB[itag]['codec'] == 'VP8/vorbis':
                            if acodec == 1:
                                order = order + 90000
                            else:
                                order = order + 10000
                    except :
                        order = order + 30000

                    try:
                        if containerDB[container] == 'MP4':
                            if pformat == 0 or pformat == 1:
                                order = order + 100
                            elif pformat == 3 or pformat == 4:
                                order = order + 200
                            else:
                                order = order + 300
                        elif containerDB[container] == 'flv':
                            if pformat == 2 or pformat == 3:
                                order = order + 100
                            elif pformat == 1 or pformat == 5:
                                order = order + 200
                            else:
                                order = order + 300
                        elif containerDB[container] == 'WebM':
                            if pformat == 4 or pformat == 5:
                                order = order + 100
                            elif pformat == 0 or pformat == 1:
                                order = order + 200
                            else:
                                order = order + 300
                        else:
                            order = order + 100
                    except :
                        pass

                    try:
                        mediaURLs.append( mediaurl.mediaurl('https://' + videoURL, itagDB[itag]['resolution'] + ' - ' + containerDB[container] + ' - ' + itagDB[itag]['codec'], str(itagDB[itag]['resolution'])+ '_' + str(order+count), order+count, title=title))
                    except KeyError:
                        mediaURLs.append(mediaurl.mediaurl('https://'+ videoURL, itagDB[itag]['resolution'] + ' - ' + container, str(itagDB[itag]['resolution'])+ '_' + str(order+count), order+count, title=title))
        
        return mediaURLs,value
        
def googledrive_resolve(id):
    import Addon
    global tv_mode
    logging.warning('google id::'+'https://drive.google.com/file/d/'+id+'/view')
    links_data,cookie=getPublicStream('https://drive.google.com/file/d/'+id+'/view')

    mediaURLs = sorted(links_data)
    options = []
    all_mediaURLs=[]
    for mediaURL in mediaURLs:
        logging.warning(mediaURL.qualityDesc)
        if '4k' in mediaURL.qualityDesc:
           
           options.append('4000')
        elif '1080' in mediaURL.qualityDesc:
           
           options.append('1080')
        elif '720' in mediaURL.qualityDesc:
           
           options.append('720')
        elif '480' in mediaURL.qualityDesc:
           
           options.append('480')
        elif '360' in mediaURL.qualityDesc:
           
           options.append('360')
        elif '240' in mediaURL.qualityDesc:
           
           options.append('240')
        else:
           
           options.append('0')
        all_mediaURLs.append((mediaURL.url,fix_q(mediaURL.qualityDesc)))
    qualities=options
    qualities=sorted(options, key=lambda x: x[0], reverse=True)
    all_mediaURLs=sorted(all_mediaURLs, key=lambda x: x[1], reverse=True)
    
    if Addon.getSetting("auto_q")=='true':
            f_l=qualities[0]
            max_q=int(Addon.getSetting("quality"))
            
            xx=0
            p_qualities=[]
            for items in qualities:
               
               if fix_q(items)<max_q:
                
                 p_qualities.append(xx)
               xx+=1
            yy=0
            f_q=[]
            for items in qualities:
                 if yy not in p_qualities:
                  f_q.append(items)
                 yy+=1
            qualities=f_q
            if len(qualities)>0:
              f_l=len(qualities)-1

            playbackURL,qul = all_mediaURLs[f_l]
         
    else:
        ret = xbmcgui.Dialog().select("בחר איכות", options)
        if ret==-1:
            sys.exit()
        
        playbackURL = mediaURLs[ret].url


    final_link=playbackURL
    return (final_link+'||Cookie=DRIVE_STREAM%3D'+cookie) 
   
def fix_q(quality):
    
    
    if '1080' in quality:
      f_q=0
    elif '720' in quality:
      f_q=1
    elif '480' in quality:
      f_q=2
   
    elif '360' in quality or 'sd' in quality.lower():
      f_q=3
   
    return f_q
def get_rapid(url):
      import Addon
      from raptu import resolve,resolve_video
      dialog = xbmcgui.Dialog()
      video_data = resolve(url)
   
      videos = video_data['videos']
      link=url
      qualities = sorted([_x.encode("UTF8") for _x in videos.keys()], key=lambda _q: int(filter(str.isdigit, _q)))
      logging.warning(videos)
      if '777' in qualities:
       
        link = videos['777']
      else:
      
          logging.warning(Addon.getSetting("auto_q"))
          if Addon.getSetting("auto_q")=='true':
            f_l=qualities[0]
            max_q=int(Addon.getSetting("quality"))
            
            xx=0
            p_qualities=[]
            for items in qualities:
               
               if fix_q(items)<max_q:
                
                 p_qualities.append(xx)
               xx+=1
            yy=0
            f_q=[]
            for items in qualities:
                 if yy not in p_qualities:
                  f_q.append(items)
                 yy+=1
            qualities=f_q
            if len(qualities)>0:
              f_l=qualities[len(qualities)-1]
            
            link =  (videos[ f_l]) 
          else:
              ret = dialog.select("Choose quality to play", qualities)
              if ret != -1:
                link = (videos [qualities[ret]]) 
      return link
def get_vidshare2(url):
    headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',
        'Accept-Language': 'en-US,en;q=0.9',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Cache-Control': 'no-cache',
        'X-Requested-With': 'XMLHttpRequest',
        'Connection': 'keep-alive',
        
    }
    html=requests.get(url,headers=headers).content
    regex='file:"(.+?)"'
    match=re.compile(regex).findall(html)[0]
    return match
def get_f2h(url):
        url=url.replace('nana10.co.il','io')
        headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',


        
        }
        html=requests.get(url,headers=headers).content
        
        regex='<script.+?"(.+?)/ip.php'
        match=re.compile(regex).findall(html)

        for links in match:
         
         if 'f2h.co.il' in links:
           id=links

        regex2="<form name='myform' id='myform' method='post' action='.+?/thanks/(.+?)'"
        match2=re.compile(regex2).findall(html)

        link=id+'/files/'+match2[0].replace("|","%7C")
        return link
def resolve_vidlink(url):

    from jsunpack import unpack
    headers = {
        'pragma': 'no-cache',
        
        'origin': 'https://vidlink.org',
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
        'accept': 'application/json, text/javascript, */*; q=0.01',
        'cache-control': 'no-cache',
        'authority': 'vidlink.org',
        'x-requested-with': 'XMLHttpRequest',
        'referer':url,
        'content-length': '0',
    }

    id_view_pre = requests.post('https://vidlink.org/embed/update_views', headers=headers).json()
    id_view=id_view_pre['id_view']
    logging.warning(id_view)
    postIDs=url.split('/')
    postID=postIDs[len(postIDs)-1]
    headers = {
        'origin': 'https://vidlink.org',
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'x-requested-with': 'XMLHttpRequest',
        
        'pragma': 'no-cache',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'accept': 'text/html, */*; q=0.01',
        'cache-control': 'no-cache',
        'authority': 'vidlink.org',
        'referer': url,
    }

    data = [
      ('browserName', 'Chrome'),
      ('platform', 'Win32'),
      ('postID', postID),
      ('id_view',id_view),
    ]

    response = requests.post('https://vidlink.org/streamdrive/info', headers=headers, data=data).content
    link=unpack(response)
    regex='window.srcs=(.+?);'
    match=re.compile(regex).findall(link)[0]
    jlink=json.loads(match)
    
    logging.warning('https://vidlink.org'+jlink[0]['src'])
    head=urllib.urlencode(headers)
       
    return urllib.unquote(jlink[0]['src'].replace('/redirect?url=',''))+"|"+head
def get_hex(url):
    if 'http' not in url:
      url='http:'+url
    headers = {
        
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'x-requested-with': 'XMLHttpRequest',
        
        'pragma': 'no-cache',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'accept': 'text/html, */*; q=0.01',
        'cache-control': 'no-cache',

    }
    x=requests.get(url,headers=headers).content
    regex='</div><script type="text/javascript">(.+?)</script>'
    match=re.compile(regex,re.DOTALL).findall(x)[0]

    from jsunpack import unpack
    data=unpack(match)
    regex='sources.+?\[(.+?)\]'
    match=re.compile(regex,re.DOTALL).findall(data)[0]
    logging.warning(match)
    j_m=json.loads('['+match+']')
    
    all_res=[]
    all_lk=[]
    for items in j_m:
       
        if 'label' in items:
            all_res.append(items['label'])
        else:
            all_res.append('unk')
        all_lk.append(items['file'])
    ret = xbmcgui.Dialog().select("בחר איכות", all_res)
    if ret!=-1:
        f_link=all_lk[ret]
    else:
      sys.exit()
    return f_link
def getclick(url):
    headers = {
        
        'accept-encoding': 'utf-8',
        'accept-language': 'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',
        'x-requested-with': 'XMLHttpRequest',
        
        'pragma': 'no-cache',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/68.0.3440.106 Safari/537.36',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'accept': 'text/html, */*; q=0.01',
        'cache-control': 'no-cache',

    }
    x=requests.get(url,headers=headers).content
    regex='name="id" value="(.+?)"'
    nm=re.compile(regex,re.DOTALL).findall(x)[0]
    
    regex='name="fname" value="(.+?)"'
    fn=re.compile(regex,re.DOTALL).findall(x)[0]
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': url,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }

    data = {
      'op': 'download1',
      'usr_login': '',
      'id': nm,
      'fname': fn,
      'referer': '',
      'method_free': 'Free Download >>'
    }

    response = requests.post(url, headers=headers, data=data).content
    
    regex='document.location = "(.+?)"'
    final=re.compile(regex,re.DOTALL).findall(response)[0]
    
    


    data = {
      'op': 'download2',
      'id': nm,
      'rand': '',
      'referer': url,
      'method_free': 'Free Download >>',
      'method_premium': ''
    }

    response = requests.post(url, headers=headers, data=data).content
    
    regex="onClick=\"window.open\('(.+?)'"
    final=re.compile(regex,re.DOTALL).findall(response)[0]
    head=urllib.urlencode(headers)
    final=final+"|"+head
        
    return final
def get_cloud(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex='"request".+?"weblink".+?"(.+?)"'
    wl=re.compile(regex,re.DOTALL).findall(x)[0]
    
    regex='"weblink_view".+?"url": "https://(.+?)/weblink/view/"'
    base=re.compile(regex,re.DOTALL).findall(x)[0]
    
    regex='"hash".+?"(.+?)"'
    hash=re.compile(regex,re.DOTALL).findall(x)[0]
    
    regex='"tokens".+?"download".+?"(.+?)"'
    key=re.compile(regex,re.DOTALL).findall(x)[0]
    
    flink='https://%s/weblink/view/'%base+wl+'?etag=%s&key=%s'%(hash,key)
   
    head=urllib.urlencode(headers)
    flink=flink+"|"+head
    return flink
def get_usercloud(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': url,
    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex='source src="(.+?)"'
    flink=re.compile(regex).findall(x)[0]
    head=urllib.urlencode(headers)
    flink=flink+"|"+head
    return flink
def get_mystr(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
   
    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    
    html=requests.get(url,headers=headers).content
    regex='ﾟωﾟﾉ(.+?)var'
    m=re.compile(regex,re.DOTALL).findall(html)
    test=html
    if len(m)>0:
        from open import AADecoder
        test=AADecoder('ﾟωﾟﾉ'+m[0]).decode()
        logging.warning(test)
    regex="'src', '(.+?)'"
    flink=re.compile(regex).findall(test)[0]
    head=urllib.urlencode(headers)
    flink=flink+"|"+head
    return flink
def get_vidoza(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
   
    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex='source src="(.+?)"'
    flink=re.compile(regex).findall(x)[0]
    head=urllib.urlencode(headers)
    flink=flink+"|"+head
    return flink
def get_gounlimited(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
   
    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    x=requests.get(url,headers=headers).content
    regex="<script type='text/javascript'>(.+?)</script>"
    data=re.compile(regex,re.DOTALL).findall(x)[0]
    from jsunpack import unpack
    u_data=unpack(data)
   
    regex='src.+?"(.+?")'
    flink=re.compile(regex,re.DOTALL).findall(u_data)[0]
    head=urllib.urlencode(headers)
    flink=flink+"|"+head
    return flink
def resolve_mys(url):
    from open import AADecoder
    url=url.replace('mystream.to/watch','embed.mystream.to')
    
    cookies = {

    'ref_url': url,

    }
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get(url, headers=headers, cookies=cookies).content
    
    regex='<script>(.+?)</script>'
    flink=re.compile(regex).findall(response)[0]
    data=(AADecoder(flink).decode())
    regex="'src', '(.+?)'"
    flink=re.compile(regex).findall(data)[0]
    return flink
def  get_vidhd(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',

        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get(url, headers=headers).content
    regex='file:"(.+?)",label:"(.+?)"'
    flink=re.compile(regex).findall(response)
    all_q=[0]
    all_l=[0]
    for link,q in flink:
        all_q.append(q)
        all_l.append(link)
    
   
    return all_l[all_q.index(max(all_q))]
def get_tus(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
       
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get(url, headers=headers).content
    regex='source src="(.+?)"'
    flink=re.compile(regex).findall(response)[0]
  
    return flink
def resolve_upvid(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
       
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    response = requests.get(url, headers=headers).content
    regex='"iframe" src="(.+?)"'
    flink=re.compile(regex).findall(response)[0]
  
    return flink
def resolve_filepursuit(url):
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
}
    x,cook=cloudflare_request(url,headers=headers)
    logging.warning(x)
    regex='id="visible-input">(.+?)<'

    link=re.compile(regex).findall(x)[0]
    logging.warning(link)
    return link

def resolve_mediafire(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:62.0) Gecko/20100101 Firefox/62.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
       
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }
    x=requests.get(url,headers=headers).content
    regex='<a class="DownloadButtonAd-startDownload gbtnSecondary" href=\'(.+?)\''
    match=re.compile(regex).findall(x)
    
    return match[0]
def resolve_cat(url):
    x=requests.get(url,headers=base_header).url
    return x
class Platform(object):
    class __metaclass__(type):
        def __getattr__(cls, name):
            getattr(cls, "_%s" % name)()
            return getattr(cls, name)

        def _arch(cls):
            if sys.platform.lower().startswith('linux') and (os.uname()[4].lower().startswith('arm') or os.uname()[4].lower().startswith('aarch')):
                cls.arch = 'arm'
            elif sys.maxsize > 2**32 or sys.platform.lower().startswith('linux') and os.uname()[4].lower().startswith('x86_64'):
                cls.arch = 'x64'
            else:
                cls.arch = 'x86'

        def _system(cls):
            if sys.platform.lower().startswith('linux'):
                cls.system = 'linux'
                if 'ANDROID_DATA' in os.environ:
                    cls.system = 'android'
            elif sys.platform.lower().startswith('win'):
                cls.system = 'windows'
            elif sys.platform.lower().startswith('darwin'):
                cls.system = 'darwin'
            else:
                cls.system = None
class LogPipe(Thread):
    import logging
    def __init__(self):
        
        self._read_fd, self._write_fd = os.pipe()
        super(LogPipe, self).__init__(target=self.run)

    def fileno(self):
        return self._write_fd

    def run(self):
        logging.warning("Logging started")
        with os.fdopen(self._read_fd) as f:
            for line in iter(f.readline, ""):
                line = re.sub(r'^\d+/\d+/\d+ \d+:\d+:\d+ ', '', line)
                logging.warning(line.strip())
                if self.stop.is_set():
                    break
        logging.warning("Logging finished")
def resolve_magnet(url):
    import Addon
    allow_rd=Addon.getSetting("rdsource")
    if allow_rd=='true':
        return url
    from kodipopcorntime.torrent import TorrentPlayer
    from kodipopcorntime import settings
    mediaSettings = getattr(settings, 'movies')
    item={'info': {'rating': 0.0, 'plotoutline': 'Elastigirl springs into action to save the day, while Mr. Incredible faces his greatest challenge yet \xe2\x80\x93 taking care of the problems of his three children.', 'code': 'tt3606756', 'director': '', 'studio': '', 'year': 2018, 'genre': 'animation / family / action / adventure / superhero', 'plot': 'Elastigirl springs into action to save the day, while Mr. Incredible faces his greatest challenge yet \xe2\x80\x93 taking care of the problems of his three children.', 'votes': 0.0, 'castandrole': [], 'title': 'Playing', 'tagline': '1080p: 18930 seeds; 720p: 14301 seeds; ', 'writer': '', 'originaltitle': 'Incredibles 2'}, 'thumbnail': 'http://image.tmdb.org/t/p/w500/x1txcDXkcM65gl7w20PwYSxAYah.jpg', 'stream_info': {'subtitle': {'language': ''}, 'audio': {'channels': 2, 'codec': 'aac', 'language': 'en'}, 'video': {'width': 1920, 'codec': 'h264', 'height': 720}}, 'label': 'Incredibles 2', 'properties': {'fanart_image': 'http://image.tmdb.org/t/p/w500/mabuNsGJgRuCTuGqjFkWe1xdu19.jpg'}, 'icon': 'http://image.tmdb.org/t/p/w500/x1txcDXkcM65gl7w20PwYSxAYah.jpg'}
    return TorrentPlayer().playTorrentFile(mediaSettings, url, item, None)
def resolve_lime(url):
    import Addon
    headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
    x=requests.get(url,headers=headers).content
    regex='"magnet:(.+?)"'
    url='magnet:'+re.compile(regex).findall(x)[0]
    allow_rd=Addon.getSetting("rdsource")
    if allow_rd=='true':
        return url
    from kodipopcorntime.torrent import TorrentPlayer
    from kodipopcorntime import settings
    mediaSettings = getattr(settings, 'movies')
    item={'info': {'rating': 0.0, 'plotoutline': 'Elastigirl springs into action to save the day, while Mr. Incredible faces his greatest challenge yet \xe2\x80\x93 taking care of the problems of his three children.', 'code': 'tt3606756', 'director': '', 'studio': '', 'year': 2018, 'genre': 'animation / family / action / adventure / superhero', 'plot': 'Elastigirl springs into action to save the day, while Mr. Incredible faces his greatest challenge yet \xe2\x80\x93 taking care of the problems of his three children.', 'votes': 0.0, 'castandrole': [], 'title': 'Playing', 'tagline': '1080p: 18930 seeds; 720p: 14301 seeds; ', 'writer': '', 'originaltitle': 'Incredibles 2'}, 'thumbnail': 'http://image.tmdb.org/t/p/w500/x1txcDXkcM65gl7w20PwYSxAYah.jpg', 'stream_info': {'subtitle': {'language': ''}, 'audio': {'channels': 2, 'codec': 'aac', 'language': 'en'}, 'video': {'width': 1920, 'codec': 'h264', 'height': 720}}, 'label': 'Incredibles 2', 'properties': {'fanart_image': 'http://image.tmdb.org/t/p/w500/mabuNsGJgRuCTuGqjFkWe1xdu19.jpg'}, 'icon': 'http://image.tmdb.org/t/p/w500/x1txcDXkcM65gl7w20PwYSxAYah.jpg'}
    return TorrentPlayer().playTorrentFile(mediaSettings, url, item, None)
def get_bee(url):
    x=requests.get(url,headers=base_header).content
   
    headers = {
        'authority': 'thevideobee.to',
        'pragma': 'no-cache',
        'cache-control': 'no-cache',
        'origin': 'https://thevideobee.to',
        'upgrade-insecure-requests': '1',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/77.0.3865.90 Safari/537.36',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
        'sec-fetch-site': 'same-origin',
        'referer': url,
        'accept-encoding': 'utf-8',
        'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
        
    }
    ids=url.split('/')
    id=ids[len(ids)-1].replace('.html','')
    has=re.compile('ame="hash" value="(.+?)"').findall(x)[0]
    
    data = {
      'op': 'download1',
      'usr_login': 'Romeo786',
      'id': id,
      'fname': 'London.Rampage.2018.1080p.WEBRip.x264.YTS.LT.mp4',
      'referer': '',
      'hash': has,
      'imhuman': 'Proceed to video'
    }

    response = requests.post('https://thevideobee.to/88k39zghwpaa.html', headers=headers, data=data).content

    regex_pre='sources: \["(.+?)"'
    m_pre=re.compile(regex_pre).findall(response)
    
    return m_pre[0]
def get_cloudvideo(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',

    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Referer': url,
        'Origin': 'https://cloudvideo.tv',
        'Connection': 'keep-alive',
    }

    x=requests.get(url,headers=headers).content
    regex='source src="(.+?)"'
    m=re.compile(regex).findall(x)[0]

    if 'master.m3u8' in m:
        y=requests.get(m,headers=headers).content
        regex='#EXT-X-STREAM(.+?)\n(.+?)\n'
        m2=re.compile(regex).findall(y)
        res=[]
        al=[]
        
        for data,link in m2:
          
            
            al.append(link)
            if 'RESOLUTION' in data:
                regex='RESOLUTION=(.+?),'
                res.append(re.compile(regex).findall(data)[0])
            else:
                res.append('NA')
        regex='#EXT-X-I-FRAME(.+?)URI="(.+?)"'
        m2=re.compile(regex,re.DOTALL).findall(y)
   
        for data,link in m2:
          
            
            al.append(link)
            if 'RESOLUTION' in data:
                regex='RESOLUTION=(.+?),'
                res.append(re.compile(regex).findall(data)[0])
            else:
                res.append('NA')
        ret = xbmcgui.Dialog().select("בחר איכות", res)
        if ret==-1:
            sys.exit()
        else:
            m=al[ret]
    head=urllib.urlencode(headers)
    m=m+"|"+head
    return m
def get_vidcloud(url):
    if 'googlevideo' in url:
        return url
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',

    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
  
    y=requests.get(url,headers=headers).content
  
    regex="fileID = '(.+?)'"
    m2=re.compile(regex).findall(y)
    if len(m2)>0:
        m2=m2[0]
        logging.warning(m2)
        

        params = (
            ('fid', m2),
            ('page', 'embed'),
        )
        logging.warning('2')
        response = requests.get('https://vidcloud.online/player', headers=headers, params=params).json()
        
        data = re.findall('sources = (\[\{.+?\}\])',response['html'], re.DOTALL)[0]

        try:
            data = json.loads(data)
        except:
            data=data.replace('file','"file"').replace('label','"label"')
            data = json.loads(data)
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://vidcloud.icu/',
            'Origin': 'https://vidcloud.icu',
            'Connection': 'keep-alive',
        }
        head=urllib.urlencode(headers)
        return data[0]['file']+"|"+head
    else:
        data = re.findall('sources:(\[\{.+?\}\])',y, re.DOTALL)[0]

        try:
            data = json.loads(data)
        except:
            try:
                data=data.replace('file:','"file":').replace('label:','"label":')
                data = json.loads(data)
            except:
                data=data.replace('"file":',"'file':").replace('"label":',"'label':")
                logging.warning(data)
                data = json.loads(data.replace("'",'"'))
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.5',
            'Referer': 'https://vidcloud.icu/',
            'Origin': 'https://vidcloud.icu',
            'Connection': 'keep-alive',
        }
        head=urllib.urlencode(headers)
   
        return data[0]['file']+"|"+head
def resolve_xst(url):
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:65.0) Gecko/20100101 Firefox/65.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': url,
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Connection': 'keep-alive',
    'Cache-Control': 'max-age=0',
    }

    data = {
      'r': '',
      'd': 'xstreamcdn.com'
    }

    response = requests.post(url.replace('https://xstreamcdn.com/v/','https://xstreamcdn.com/api/source/'), headers=headers,  data=data).json()
    q=0
    max=0
    l_link=''
    for items in response['data']:
        try:
            q=int(items['label'].replace('p',''))
        except:
            pass
        if q>=max:
            l_link=items['file']
    return l_link
def resolve_unlim(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',

    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
  
    y=requests.get(url,headers=headers).content
  
    regex="urlVideo = '(.+?)'"
    m2=re.compile(regex).findall(y)
    return m2[0]
def resolve_megax(url):
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:64.0) Gecko/20100101 Firefox/64.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',

    'Content-Type': 'application/x-www-form-urlencoded',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }
  
    y=requests.get(url,headers=headers).content
  
    regex="fileID = '(.+?)'"
    m2=re.compile(regex).findall(y)
    y=requests.get('https://megaxfer.ru/player?fid=%s&page=embed'%m2[0],headers=headers).json()

    regex='sources.+?\[(.+?)\]'
    match=re.compile(regex,re.DOTALL).findall(y['html'])[0]
    logging.warning('['+match+']')
    j_m=json.loads('['+match+']')
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': url,
    'Origin': 'https://megaxfer.ru',
    'Connection': 'keep-alive',
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }
    for items in j_m:
       
        if 'file' in items:
            head=urllib.urlencode(headers)
            f_link=items['file']#+"|"+head
            return f_link
            urls.append(items['file'])
    return m2[0]
def resolve_thevid(url):
    from jsunpack import unpack
    url=url.replace('http://thevid.net/v/','http://thevid.net/e/')
    headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
    
   
    html=requests.get(url,headers=headers).content
    regex='<script>(.+?)</script>'
    m2=re.compile(regex,re.DOTALL).findall(html)

    for items in m2:
       
        if 'eval' in items:
            data=unpack(items)
           
            regex='var ldAb="(.+?)"'
            m=re.compile(regex).findall(data)
            if len(m)>0:
                if 'http' not in m[0]:
                    return 'http:'+m[0]
                else:
                    return m[0]
def get_vidupl(url):
    from jsunpack import unpack
    logging.warning('In vidplayer')
    if 'embed-' in url:
        
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:67.0) Gecko/20100101 Firefox/67.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }
        
       
        html=requests.get(url,headers=headers).content
        regex="<script type='text/javascript'>(.+?)</script>"
        m2=re.compile(regex,re.DOTALL).findall(html)

       
           
          
        data=unpack(m2[0])
        
        regex='file:"(.+?)"'
        m=re.compile(regex).findall(data)
        
        if 'http' not in m[0]:
            return 'http:'+m[0]
        else:
            return m[0]
def resolve_vidb(url):
   
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; rv:66.0) Gecko/20100101 Firefox/66.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

    html=requests.get(url,headers=headers).content
    regex="file_id', '(.+?)'"
    f_id=re.compile(regex).findall(html)[0]
    cookies = {
    'lang': '1',
    'file_id': f_id,
    
    }
    html=requests.get(url,headers=headers,cookies=cookies).content
    regex='ﾟωﾟﾉ(.+?)var'
    m=re.compile(regex,re.DOTALL).findall(html)
    test=html
    if len(m)>0:
        from open import AADecoder
        test=AADecoder('ﾟωﾟﾉ'+m[0]).decode()
        logging.warning(test)
    regex='file:"(.+?)"'
    lk= re.compile(regex).findall(test)[0]
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0',
        'Accept': 'video/webm,video/ogg,video/*;q=0.9,application/ogg;q=0.7,audio/*;q=0.6,*/*;q=0.5',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Referer': url,
        
        'Connection': 'keep-alive',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }
    head=urllib.urlencode(headers)
    lk=lk+"|"+head
    return lk
    regex="'file_id', '(.+?)'"
    cook=re.compile(regex).findall(html)[0]
    cookies = {
        
        'file_id': cook,
        
    }
    html=requests.get(url,headers=headers,cookies=cookies).content
    data = re.findall('sources:([^]]+\])',html, re.DOTALL)[0]
                           
    try:
        data = json.loads(data)
    except:
        data=data.replace('file','"file"').replace('label','"label"')
        data = json.loads(data)
    data = [(i['file'], i['label']) for i in data if data]
    for end_url, rez in data:
    
      if 'http' not in end_url:
        n_link='http:'+end_url
      else:
        n_link=end_url
    head=urllib.urlencode(headers)
    n_link=n_link+"|"+head
    
    return n_link
def resolve_verystream(url):
    
    x=requests.get(url,headers=base_header).content
    regex='id="videolink">(.+?)<'
    m=re.compile(regex,re.DOTALL).findall(x)
    return 'https://verystream.com/gettoken/'+m[0]

    
def resolve_gcloud(url):
    headers = {
        'Accept': '*/*',
        'Referer': url,
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
        'Sec-Fetch-Mode': 'cors',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    }

    data = {
      'r': '',
      'd': 'gcloud.live'
    }
    ids=url.split('/')
    id=ids[len(ids)-1]
    response = requests.post('https://gcloud.live/api/source/'+id, headers=headers, data=data).json()
    logging.warning(response)
    
    return response['data'][len(response['data'])-1]['file']
    
def resolve_vidhd(url):
    from jsunpack import unpack
    headers = {
        'Accept': '*/*',
        
        'X-Requested-With': 'XMLHttpRequest',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Safari/537.36',
        'Sec-Fetch-Mode': 'cors',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    }
    x=requests.get(url,headers=headers).content
    regex="<script type='text/javascript'>(.+?)</script>"
    m=re.compile(regex,re.DOTALL).findall(x)
    logging.warning(m)
    temp=unpack(m[0])
    logging.warning(temp)
    
    regex_link='file:"(.+?)"'
    match_link=re.compile(regex_link).findall(temp)[0]
    return match_link
def resolve_only(url):
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
    logging.warning('In Onlystream')
    x=requests.get(url,headers=headers).content
   
    regex='file:"(.+?)"'
    match=re.compile(regex).findall(x)
    if len(match)==0:
       
        regex='"file":"(.+?)"'
        match=re.compile(regex).findall(x)
        if len(match)==0:
            regex='src: "(.+?)"'
            match=re.compile(regex).findall(x)
    logging.warning(match)
    
    for it_lk in match:
        
        lk=it_lk
        
        return lk
    '''
    regex="download_video\('(.+?)','o','(.+?)'\)"
    m=re.compile(regex).findall(x)
    lk='https://onlystream.tv/dl?op=download_orig&id=%s&mode=o&hash=%s'%(m[0][0],m[0][1])
    logging.warning(lk)
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:69.0) Gecko/20100101 Firefox/69.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }

    y=requests.get(lk,headers=headers).content
    logging.warning(y)
    regex='"btn btn-primary btn-go" href="(.+?)"'
    m=re.compile(regex).findall(y)
    logging.warning(m)
    return m[0]
    '''
def resolve_vcdn(url):
    ids=url.split('/')
    id=ids[len(ids)-1]
    
    headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Origin': 'https://vcdn.io',
    'Connection': 'keep-alive',
    'Referer': url,
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    }

    data = {
      'r': '',
      'd': 'vcdn.io'
    }

    response = requests.post('https://vcdn.io/api/source/'+id, headers=headers, data=data).json()
 
    return response['data'][len(response['data'])-1]['file']
def get_arab(url):
    import unjuice
    from jsunpack import unpack
    headers = {
    'authority': 'arabramadan.com',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-mode': 'nested-navigate',
    'referer': url,
    'accept-encoding': 'utf-8',
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    
    }

    response = requests.get(url, headers=headers).content
    regex='JuicyCodes\.Run\((.+?)\)'
    rr=re.compile(regex).findall(response)[0]
    regex='"(.+?)"'
    tt=re.compile(regex).findall(rr)
    all_d=[]
    for items in tt:
        logging.warning(items)
        all_d.append(items)
    logging.warning(''.join(all_d))
    juice = (''.join(all_d)).decode('base64')
    uk=unpack(juice)
    logging.warning(uk)
    data = re.findall('sources:(\[\{.+?\}\])',uk, re.DOTALL)[0]
   
    try:
        data = json.loads(data)
    except:
        data=data.replace('src','"src"').replace('label','"label"')
        data = json.loads(data)
    data = [(i['src'], i['label']) for i in data if data]
    headers = {
    'authority': 'zeus.arabcdn.co',
    'pragma': 'no-cache',
    'cache-control': 'no-cache',
    'accept-encoding': 'identity;q=1, *;q=0',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.87 Safari/537.36',
    'accept': '*/*',
    'sec-fetch-site': 'cross-site',
    'sec-fetch-mode': 'no-cors',
    'referer': url,
    'accept-language': 'en-GB,en-US;q=0.9,en;q=0.8',
    
    }


    for end_url, rez in data:
        logging.warning(end_url)
    head=urllib.urlencode(headers)
    end_url=end_url+"|"+head
    return end_url
def resolve_vidsrc(url):
    
   x=requests.get(url.replace('embed','server1'),headers=base_header).content
   
   regex='var query = "(.+?)"'
   m=re.compile(regex).findall(x)
   headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Connection': 'keep-alive',
        'Referer': url.replace('embed','server1'),
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'TE': 'Trailers',
    }

   
   x=requests.get('https://vidsrc.me/watching'+m[0],headers=headers).url
   if x.endswith('/'):
        x=x[:-1]
   ids=x.split('/')
   logging.warning(ids)
   id=ids[len(ids)-1]
   headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0',
    'Accept': '*/*',
    'Accept-Language': 'en-US,en;q=0.5',
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
    'X-Requested-With': 'XMLHttpRequest',
    'Origin': 'https://www.vidsource.me',
    'Connection': 'keep-alive',
    'Referer': x,
    'Pragma': 'no-cache',
    'Cache-Control': 'no-cache',
    'TE': 'Trailers',
    }

   data = {
      'r': url.replace('embed','server1'),
      'd': 'www.vidsource.me'
    }

   response = requests.post('https://www.vidsource.me/api/source/'+id, headers=headers, data=data).json()
   return response['data'][len(response['data'])-1]['file']
def get_stream(url):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:74.0) Gecko/20100101 Firefox/74.0',
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.5',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'Origin': 'https://stream2you.xyz',
        'Connection': 'keep-alive',
        'Referer': url,
        'TE': 'Trailers',
    }

    data = {
      'r': '',
      'd': 'stream2you.xyz'
    }
    ids=url.split('/')
    id=ids[len(ids)-1]
    response = requests.post('https://stream2you.xyz/api/source/'+id, headers=headers, data=data).json()
    head=urllib.urlencode(headers)
    url=response['data'][len(response['data'])-1]['file']+"|"+head
    return url
  
    

def resolver(url):
    logging.warning(url)
    logging.warning('Rurl')
    if 'watchcartoononline' in url:
        import base64,urlparse
        headers = {
            
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:58.0) Gecko/20100101 Firefox/58.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        }
    
        url = url.replace('direct/', '') # Strip our episode tag off.
        html=requests.get(url,headers=headers)
        

        url = ''
      
        match = re.findall('''var\s*[a-zA-Z]{3}\s*\=\s*\[([^\]]+)''', html.text)[0]
        spread = re.findall('''-\s*(\d+)\)\;\s*\}''', html.text)[0]
        match = re.findall('''['"]([^'"]+)['"]''', match)

        for i in match:
            i = base64.b64decode(i)
            i = re.findall(r'(\d+)',i)[0]
            i = chr(int(i) - int(spread))
            url += i
        url = re.findall(r'src="(.*?)"', url.replace("embed", "embed-adh"))[0]
        url = urlparse.urljoin('https://www.watchcartoononline.io', url)
        url = requests.get(url)
        url = re.findall(r'''file:\s*['\"]([^'\"]+)['\"](?:\,\s*label:\s*|)(?:['\"]|)([\d]+|)''', url.text)
        url_f=[]
        all_q=[]
        url_gg = [(i[0],'0' if i[1] == '' else i[1]) for i in url]
       
        for i in url:
             if i[1] != '':
             
                url_f.append(i[0])
                all_q.append(i[1])
             else:
                url_f.append(i[0])
               
    
        #url = [(i[0],'0' if i[1] == '' else i[1]) for i in url]
        
        if len(url_f)>1:
            ret=xbmcgui.Dialog().select("בחר", all_q)
           
            return url_f[ret]
            
        else:
            return url_f[0]
    if 'anime-spin' in url:
        from jsunpack import unpack
        headers = {
        'Pragma': 'no-cache',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'en-US,en;q=0.9',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
  
        }   

        x=requests.get(url,headers=headers).content
        regex='<iframe src="(.+?)"'
        
        match=re.compile(regex).findall(x)[0]
        if 'mp4' in match:
            y=requests.get(match,headers=headers).content
    
            
            regex="eval(.+?)</script>"
            match=re.compile(regex,re.DOTALL).findall(y)[0]
            data=unpack('eval'+match)
          
            regex='file.+?"(.+?)"'
            match=re.compile(regex).findall(data)[0]
            return match
        elif 'stream.moe' in match:
            y=requests.get(match,headers=headers).content
    
           
            regex="atob\('(.+?)'"
            match=re.compile(regex).findall(y)[0].decode('base64')
            regex='source src="(.+?)"'
            return re.compile(regex).findall(match)[0]
        elif 'dailymotion' in match:
           import resolveurl
           return resolveurl.resolve(match)
        else:
           url=match
 
    if 'youtube' in url and 'googlevideo' not in url:
        import urlparse
       
        parsed = urlparse.urlparse(url)
        id=  urlparse.parse_qs(parsed.query)['v']
        return 'plugin://plugin.video.youtube/?action=play_video&videoid=%s'%id[0]
    if 'nick.walla' in url:
         from kidstv_season import getLink
         return getLink(url)
    if 'f2h' in url:
      
      return get_f2h(url)
    
    if 'drive.google' in url or 'docs.google' in url:
      
      if 'docs.googleusercontent.com' in url:
        logging.warning('Returning')
        return url
      if '=' in url:
        id=url.split('=')[-1]
    
      else:
       regex='/d/(.+?)/view'
       match=re.compile(regex).findall(url)
       if len(match)>0:
         id=match[0]
       else:
         regex='/d/(.+?)/preview'
         match=re.compile(regex).findall(url)
         id=match[0]
      
      return googledrive_resolve(id)
    if 'zipansion' in url or 'infopade' in url :
      url= decrypt(url)
    if 'vcdn.io' in url:
        return resolve_vcdn(url)
    if 'vidsrc.me' in url:
        return resolve_vidsrc(url)
    if 'cutt.ly' in url:
        url=resolve_cat(url)
        logging.warning(url)
    if 'vidmoly.' in url:
       return resolve_only(url)
    if 'onlystream' in url or 'drive.ayamov.com' in url or 'vidfast' in url:
        return resolve_only(url)
    if 'vidhd.net' in url:
        return resolve_vidhd(url)
    if 'gcloud.live' in url:
        return resolve_gcloud(url)
    if 'viduplayer' in url:
        return get_vidupl(url)
    if 'vidbom.com' in url:
        return resolve_vidb(url)
    if 'thevid.net' in url:
        return resolve_thevid(url)
    if 'xstreamcdn' in url:
        return resolve_xst(url)
    if 'upvid.co' in url:
        return resolve_upvid(url)
    if 'megaxfer.ru' in url :
        return resolve_megax(url)
    if 'unlimitedpeer.ru' in url:
        return resolve_unlim(url)
    if 'limetorrents' in url:
        resolve_lime(url)
    if 'magnet:' in url:
      return resolve_magnet(url)
    if "filepursuit" in url:
        return resolve_filepursuit(url)
    if 'mediafire' in url:
      return resolve_mediafire(url)
    if 'tv4kids.tk' in url:
      return url
    if 'tusfiles' in url:
        return get_tus(url)
    if 'vidhd.net' in url:
        return get_vidhd(url)
    if 'mystream.to' in url and 'embed.' not in url :
        return resolve_mys(url)
    if 'rapidvid' in url:
      return get_rapid(url)
    if 'thevideobee' in url:
        return get_bee(url)
    if 'cloudvideo' in url:
        return get_cloudvideo(url)
    if 'verystream.com' in url:
        return resolve_verystream(url)
    if '//vidcloud.icu/' in url:
        logging.warning('111')
        return get_vidcloud(url)
    if 'arabramadan' in url:
        return get_arab(url)
    if 'willtv.net' in url:
        y=requests.get(url,headers=base_header).content
        regex='<source src="(.+?)"'
        f_link=re.compile(regex,re.DOTALL).findall(y)[0].replace('|','%7C')
        return f_link
    if 'openload' in url or 'oload' in url:
      from open import getMediaLinkForGuest
      return getMediaLinkForGuest(url)
    if 'hxload.io' in url:
      return get_hex(url)
    
    if 'clicknupload.org' in url:
      return getclick(url)
    if 'stream2you.xyz' in url:
        return get_stream(url)
    if 'uptobox' in url:
      return get_uptobox(url)
    if 'cloud.mail.ru' in url:
      return get_cloud(url)
    if 'vidoza.net' in url:
     return get_vidoza(url)
    if 'userscloud.com' in url:
      return get_usercloud(url)
    if 'embed.mystream.to' in url:
      return get_mystr(url)
    if 'vidshare' in url:
       return get_vidshare2(url)
    if 'streamango'  in url :
      return resolve_streamango(url)
      
    if 'thevideo'  in url or 'vev.io' in url :
      return resolve_thevideo(url)
      
    if 'sratim' in url :
      return fix_sratim_link(url)
      
    if 'upfile' in url :
      return get_upfile_det(url)
      
    if 'letsupload' in url :
      return get_lats(url)
      
    if 'vcstream' in url :
      return get_vcstream(url)
    if 'gounlimited.to' in url:
        return get_gounlimited(url)
    if 'req' in url and 'googlevideo' not in url:
      return get_req(url)
      
    if '[' in url and 'http' not in url:
     
      return get_sdarot(url)
      
    
      
    if 'flashx' in url :
      return decrypt(url)
      
    if '//vidup.' in url :
      return get_vidup(url)
      
    if 'vidlox' in url :
      from vidup import getMediaLinkForGuest_vidlox
      return getMediaLinkForGuest_vidlox(url)
      
    if 'vidtodo' in url :
      from vidtodo import VidToDoResolver
      return VidToDoResolver(url)
      
    if 'vidto' in url :
      from vidtodo import __get_vidto
    
      if 'embed' in url:
              regex='vidto.me/embed-(.+?)-'
              
              id=re.compile(regex).findall(url)
              if len(id)==0:
                regex='vidto.me/embed-(.+?).html'
              id=re.compile(regex).findall(url)[0]
              url='http://vidto.me/%s.html'%id
      return __get_vidto(url)[1]
    if 'vidlink' in url and 'playlist' not in url:
       return resolve_vidlink(url)
    if 'vshare' in url :
      
      if 'embed' in url:
         return get_vidshare(url,embed=True)
      else:
        
        return get_vidshare(url)
    if 'viooz' in url :
       return get_viooz(url)
    if 'ganol' in url :
       return get_ganol(url)
def isValid(url):
    supported=['stream2you.xyz','willtv.net','vidsrc.me','vcdn.io','arabramadan','vidfast','drive.ayamov.com','vidmoly','onlystream','cutt.ly','vidhd.net','gcloud.live','verystream.com','viduplayer.com','unlimitedpeer.ru','vidbom.com','thevid.net','xstreamcdn','megaxfer.ru','vev.io','vidcloud','youtube','cloudvideo','thevideobee','infopade','limetorrents','upvid.co','filepursuit','magnet:','mediafire','tusfiles','vidhd.net','mystream.to','gounlimited.to','vidoza.net','embed.mystream.to','userscloud.com','cloud.mail.ru','clicknupload.org','hxload.io','vidlink','watchcartoononline','anime-spin','youtube','nick.walla','f2h','drive.google','vidshare','rapidvid','uptobox','[','openload','oload','streamango','thevideo','sratim-il','upfile','letsupload','vcstream','reqlinks','zipansion','flashx','vidup.me','vidlox','vidtodo','vidto.','vshare','viooz','ganol']
    for items in supported:
        if items in url:
            return True
    return False
def resolve_rd(url):
    import real_debrid
    rd = real_debrid.RealDebrid()
    resolved=rd.get_link(url)['download']
    logging.warning('resolved:')
    logging.warning(resolved)
    return resolved
def resolve_rd_old(url):
    import resolveurl,xbmc
    host = url.split('//')[1].replace('www.','')
    
    debrid = host.split('/')[0].lower()
    
    debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if resolver.isUniversal()]
    all_resolve=[]
    for key in debrid_resolvers:
      all_resolve.append(key.name)
    
    if 'Real-Debrid' not in all_resolve and 'MegaDebrid' not in all_resolve:
       
       xbmc.executebuiltin("RunPlugin(plugin://plugin.video.torrent?mode=138&url=www)")
   
    if len(debrid_resolvers) == 0:

        debrid_resolvers = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True,include_universal=False) if 'rapidgator.net' in resolver.domains]

    debrid_resolver = [resolver() for resolver in resolveurl.relevant_resolvers(order_matters=True) if resolver.isUniversal()][0]
 
    debrid_resolver.login()
    _host, _media_id = debrid_resolver.get_host_and_id(url)
    logging.warning(_host)
    logging.warning(_media_id)
    stream_url = debrid_resolver.get_media_url(_host, _media_id)

    return stream_url
    
def direct_resolve(name_check):
       logging.warning('Direct Resolve')
       logging.warning(name_check)
       name_check=name_check.replace('oload.stream','openload.co')
       a= isValid(name_check)
       logging.warning('ISvalid:'+str(a))
       if 'docs.googleusercontent.com' in name_check:
            return name_check
       if '[' in name_check and 'http'  in name_check:
         a=False
       if a:
         link =resolver(name_check)
       else:
         #import resolveurl
         resolveurl=__import__ ('resolveurl')
         if 'google' in name_check and 'view' not in name_check:
            return name_check
         if 'magnet:' in name_check:
            resolvable=False
         else:
            resolvable=resolveurl.HostedMediaFile(name_check).valid_url()
         
         if resolvable:
           link =resolveurl.resolve(name_check)
           
         else:
           link=name_check
       if link==False:
         return name_check
       if link==None:
                link=name_check
       if 'ftp://' in link:
     
          link=urllib.unquote(link)
       return link
       
def get_links(url,tv_m=False):
   import Addon
   global tv_mode
   
   if tv_m:
     tv_mode=True
   else:
     tv_mode=False
   url=url.strip().replace('\n','').replace('\t','').replace('\r','')
   rd_sources=Addon.getSetting("rdsource")
   logging.warning('rd_sources')
   logging.warning(rd_sources)
   if 'watchcartoononline' in url:
    return url
   if '$$$' in url:
       url=url.split('$$$')[0]
   if rd_sources=='true' and 'youtube' not in url :
        if 'magnet' not in url:
            import real_debrid
            rd = real_debrid.RealDebrid()
            
                    
            resolvable_rd_check=rd.check_link(url)
            resolvable_rd=False
            if 'supported' in resolvable_rd_check:
                if resolvable_rd_check['supported']==1:
                    resolvable_rd=True
                    
            
        else:
            resolvable_rd=False
        if resolvable_rd and 'google' not in url:
           try:
             logging.warning('RD resolve: '+url)
             return resolve_rd(url)
           except Exception as e:
             logging.warning('Error Resolveing RD: '+str(e))
             return direct_resolve(url)
        else:
           return direct_resolve(url)
   else:
      
      return direct_resolve(url)
  
   
if local==True:
    if len(sys.argv)>1:
       
       name_check=sys.argv[1]
if local==True:
    if 'http' in name_check or '[' in name_check:
       a= isValid(name_check)
       
       if a:
         link =resolver(name_check)
       else:
         import resolveurl
         resolvable=resolveurl.HostedMediaFile(url).valid_url()
         if resolvable:
           link =resolveurl.resolve(url)
         else:
           link=name_check
      
if local==True:
    ################################Local Test#########################
    if name_check=='nick':
       from kidstv_season import getLink
       
    if name_check=='f2h':
      link='http://f2h.nana10.co.il/cyhno0ck2vdn'
      print (get_f2h(link))
    if name_check=='google':
      link='https://drive.google.com/file/d/1hU4YOguAavr1ldoMxF90KN-jJycIhK-S/view'
      if '=' in link:
        id=link.split('=')[-1]

      else:
       regex='/d/(.+?)/view'
       match=re.compile(regex).findall(link)
       if len(match)>0:
         id=match[0]
       else:
         regex='/d/(.+?)/preview'
         match=re.compile(regex).findall(link)
         id=match[0]
      print (googledrive_resolve(id))
      
    if name_check=='openload' or name_check=='oload':
      from open import getMediaLinkForGuest
      print (getMediaLinkForGuest("https://openload.co/f/XcFZ0mRF4WQ"))
    
    if name_check=='stream':
      print (resolve_streamango('https://streamango.com/f/cannttnlnqscebps/_ISRMOVIES_WEBDL_1080_2_avi'))
    if name_check=='thevideo':
      print (resolve_thevideo('https://thevideo.me/jk2hoq72qkvz'))
    if name_check=='sratim':
      print (fix_sratim_link('https://server3.sratim-il.com/%D7%AA%D7%90_211.mp4'))
    if name_check=='upfile':
      print (get_upfile_det('http://www.upfile.co.il/file/604167538.html'))
    if name_check=='lats':
      print (get_lats('https://letsupload.co/7ac/Rampage.2018.1080p.WEB-DL.x264.HalaAdana.mkv'))
    if name_check=='vcstream':
      print (get_vcstream('https://vcstream.to/embed/5b4e14cce0296/Rampage.2018.1080p'))
    if name_check=='req':
      print (get_req('http://reqlinks.net/MwhlJJwH'))
    if name_check=='sdarot':
      link='["1346", "1", "9"]'
      print (link)
      print (get_sdarot(link))
    if name_check=='sertnow':
      print (decrypt('http://zipansion.com/1uET4'))
    if name_check=='flashx':
      print (decrypt('https://www.flashx.cc/4wgjcig5kdq1.html'))
    if name_check=='vidup':
      print (get_vidup('http://vidup.tv/zdbt0yzq6fz7'))
    if name_check=='vidlox':
      from vidup import getMediaLinkForGuest_vidlox
      print (getMediaLinkForGuest_vidlox('https://vidlox.me/v16y4nd07q6z'))
    if name_check=='vidtodo':
      from vidtodo import VidToDoResolver
      print (VidToDoResolver('https://vidtodo.me/2y51qnqbxr1u'))
    if name_check=='vidto':
      from vidtodo import __get_vidto
      url= ('http://vidto.me/gn9rknfqj4eb.htm')
      if 'embed' in url:
              regex='vidto.me/embed-(.+?)-'
              id=re.compile(regex).findall(url)[0]
              url='http://vidto.me/%s.html'%id
      print (__get_vidto(url)[1])
    if name_check=='vidshare':
      url='http://vidshare.tv/embed-b8oebemf6uzj.html'
      print (get_vidshare2(url))
    if name_check=='vshare':
      url="http://www.vshare.eu/embed-hf3l1i7oegll.html"
      if 'embed' in url:
         print (get_vidshare(url))
      else:
        ids=url.split('/')
        id=ids[len(ids)-1]
        url='http://www.vshare.eu/embed-%s.html'%id
        print (get_vidshare(url))
    if name_check=='viooz':
       print (get_viooz('https://viooz.fun/3367-watch-the-mummy-resurrected-2014-1080p-bluray-x264-yify-mp4.html'))
    if name_check=='ganol':
       print (get_ganol('https://ganol.ru/film/rampage-2018-bluray-720p'))
    if name_check=='uptobox':
       print (get_uptobox('https://uptobox.com/57pyghp3jpnb'))
