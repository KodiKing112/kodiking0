# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
import requests

def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png"):
 

          
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", iconimage )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,page='0'):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)+"&page="+urllib.quote_plus(page)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok



def addLink( name, url,mode,isFolder, iconimage,fanart,description,data=''):

          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&data="+str(data)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)
 

          
         
         
          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })

          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)


def read_site_html(url_link):
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    import requests
    html=requests.get(url_link).content
    return html

def main_menu():

    
    addDir3('רבנים','https://www.hidabroot.org/api/vod/lecturers',2,'https://s3-eu-west-1.amazonaws.com/simania-public-assets/images/users/54149.jpg','http://www.yahadoot.net/upfiles/pic1x15x506T468.jpg','רבנים')
    addDir3('נושאים','https://www.hidabroot.org/api/vod/categories',2,'https://www.tlv-edu.gov.il/sites/TrainingPortal/gallery/animation_Kid%20reading%20Open%20Book.jpg','http://www.isratoys.co.il/resource/images/system-images/template4/%D7%9E%D7%95%D7%A6%D7%A8%D7%99%D7%9D/%D7%9E%D7%A9%D7%97%D7%A7%D7%99%20%D7%99%D7%94%D7%93%D7%95%D7%AA/%D7%94%D7%A8%D7%9E%D7%95%D7%A0%D7%99%D7%A7%D7%94/7564-6875647.jpg','נושאים')
    addDir3('תוכניות','https://www.hidabroot.org/api/vod/programs',2,'https://michlal.tik-tak.net/wp-content/uploadfiles/sites/256/2017/06/%D7%A1%D7%A4%D7%A8.jpg','https://www.kipa.co.il/userFiles/bf6cf7c85a2e21df89bbaf571212dd9a.jpg','תוכניות')
    addDir3('הכי נצפים','https://www.hidabroot.org/api/vod/results',3,'https://lh4.ggpht.com/nGw5vHfB5NO9xlUHF4OeyNSeTSfxurVU4EuQtfFL5cd_vQ-U1JDT6NTI6dps2peeZLM=w300','https://content.vp4.me/hidabroot/Content/unnamed_518x345.jpg','הכי נצפים')
    #addDir3('ינון קלאזן','https://www.hidabroot.org/subtitled_videos',5,'https://storage.hidabroot.org/articles/52369_tumb_750Xauto.jpg','http://acheinu.co.il/_Uploads/dbsArticles/16(6).jpg','סרטים עם כתוביות')
    addDir3('סרטים עם כתוביות','https://www.hidabroot.org/subtitled_videos',3,'https://storage.hidabroot.org/articles/52369_tumb_750Xauto.jpg','http://acheinu.co.il/_Uploads/dbsArticles/16(6).jpg','סרטים עם כתוביות')
    addLink( 'שידור חי', 'https://srv11.shidur.net/htvlive2/_definst_/smil:live2.smil/playlist.m3u8',4,False, 'https://gurutv.online/images/ch97.jpg','https://storage.hidabroot.org/videos/61465_tumb_730X500.jpg','שידור חי')
def scrape_site(name,url):




    headers = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Accept-Language': 'en-US,en;q=0.5',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
        'Host': 'www.hidabroot.org',
        'Pragma': 'no-cache',
        'Referer': 'https://www.hidabroot.org/vod',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
        'X-Requested-With': 'XMLHttpRequest',
    }

    response = requests.post(url, headers=headers).json()
    for item in response['data']:
   
      name=item['name'].encode('utf8')
      if 'pic_tumb' in item:

          image=item['pic_tumb']
          if image==False:
            image=' '
      else:
        image=' '
      link=item['link'].encode('utf8').replace("/","")
      addDir3( name, 'https://www.hidabroot.org/'+link,3, image,image,name)
def get_youtube():
    import pytube
    url='https://www.youtube.com/user/Yinonkalazan/videos'
    headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Host': 'www.youtube.com',
    'Pragma': 'no-cache',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
    }
    html=requests.get(url,headers=headers).content
    regex='"thumbnail":{"thumbnails".+?"url":"(.+?)".+?"label":"(.+?)".+?"videoId":"(.+?)"'
    match=re.compile(regex).findall(html)
    for thumb,name,id in match:
      addLink( name, id,4,False, thumb,thumb,name)
def get_links(name,url,image,plot,page):
        
        logging.warning(url)
        if 'lecturer' in url:
          lecturer=url.split("lecturer=")[1]
          type='lecturer'
          program=''
          filter=''
        elif 'category' in url:
          lecturer=url.split("category=")[1]
          type='categories[]'
          program=''
          filter=''
        elif 'program' in url:
          program=url.split("program=")[1]
          lecturer=''
          type='lecturer'
          filter=''
        elif 'results' in url:
          program=''
          lecturer=''
          type='lecturer'
          filter='views'
        elif 'subtitle' in url:
          program=''
          lecturer=''
          type='lecturer'
          filter='subtitle'

        headers = {
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Host': 'www.hidabroot.org',
            'Pragma': 'no-cache',
            'Referer': url+'&program=',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            'X-Requested-With': 'XMLHttpRequest',
        }
        data={'filter_by':filter,
              type:lecturer,
              'program':program,
              'page':page}


          
        response = requests.post('https://www.hidabroot.org/api/vod/results', headers=headers,data=data).json()
        for item in response['data']['items']:
        
              name=item['title'].encode('utf8')
              if 'pic_tumb' in item:

                  image=item['pic_tumb']
                  if image==False:
                    image=' '
              else:
                image=' '
              link=item['vid_embed'].encode('utf8')
              plot=item['content'].encode('utf8')
              addLink( name, link,4,False, image,image,plot)
        addDir3( 'עמוד הבא', url,3, ' ',' ','עמוד הבא',page=str(int(page)+1))
def play_link(name,url,plot,data):
    if 'http' not in url:
      from pytube import YouTube
      url = YouTube('https://www.youtube.com/watch?v='+url).streams.first().download()
    listItem = xbmcgui.ListItem(name, path=url) 
    listItem.setInfo(type='Video', infoLabels={'title':data,'plot':plot})


    listItem.setProperty('IsPlayable', 'true')

    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def auto_play(name,url,image,plot,data):
   import urlresolver
   dp = xbmcgui . DialogProgress ( )
   dp.create('אנא המתן','מנגן', '','')
   dp.update(0, 'אנא המתן','מנגן', '' )
   html=read_site_html(url)
   regex_pre='<div class="panel-body"(.+?)<div class='
   match_pre=re.compile(regex_pre,re.DOTALL).findall(html)
   regex='rel="nofollow" target="_blank">(.+?)<'
   regex='</p>(.+?)<a href|rel="nofollow" target="_blank">(.+?)<'
   match=re.compile(regex).findall(match_pre[0])
   z=0
   for epi,link in match:
    try:
     dp.update(int(z/(len(match)*100.0)),link,str(z)+'/'+str(len(match)),'')
     z=z+1
     if dp.iscanceled(): 
          dp.close()
          break
     link='http://'+link
     epi=epi.replace("<p>","").replace("</p>","").replace("<br>","").replace("</br>","").replace("</span>","").replace("<span>","").replace("<div>","").replace("</div>","")
     if len(link)>0:
       hmf = urlresolver.HostedMediaFile(url=link, include_disabled=False,
                 include_universal=False)
       link_r=hmf.resolve()
       if  link_r and not xbmc.Player().isPlaying():
           listItem = xbmcgui.ListItem(name, path=link_r) 
           listItem.setInfo(type='Video', infoLabels={'title':data,'plot':plot})

           xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
           while not xbmc.Player().isPlaying():
               xbmc.sleep(10) #wait until video is being played
           
       if xbmc.Player().isPlaying():
            dp.close()
            break

    except Exception as e:
     logging.warning('ERROR2222')
     logging.warning(e)
     logging.warning(z)
     dp.update(int(z/(len(match)*100.0)),link,str(z)+'/'+str(len(match)),str(e))
     pass
   logging.warning('END')
   dp.close()
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
data=None
page=0
try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:        
        data=urllib.unquote_plus(params["data"])
except:
        pass
try:        
        page=urllib.unquote_plus(params["page"])
except:
        pass

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
    scrape_site(name,url)
elif mode==3:
    get_links(name,url,iconimage,description,page)
elif mode==4:
    play_link(name,url,description,data)
elif mode==5:
    get_youtube()
xbmcplugin.setContent(int(sys.argv[1]), 'movies')
if mode!=3:
  xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_SORT_TITLE)
xbmcplugin.endOfDirectory(int(sys.argv[1]))

